var db=require('../dbconnection');

var Coupon={

getCoupon:function(Coupon,callback){
    return db.query("select * from product_coupon JOIN product_coupon_selected ON product_coupon.coupon_id = product_coupon_selected.coupon_id where product_coupon.coupon_code = '"+Coupon+"' And product_coupon.coupon_status = 'active' ",callback);
    }
};
module.exports=Coupon;