var db=require('../dbconnection');

var Filter={
	getProductTypeFilter:function(callback){
		function itemTypeList(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from product_category",function(err,pc){
					if(err) return reject([]);
					else return resolve(pc);
				});
				// return resolve([{"product_category_id":401,"product_category_name":"Men"},{"product_category_id":402,"product_category_name":"Woman"}]);
			});
		}
		function productSize(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from product_size",function(err,ps){
					if(err) return reject([]);
					else return resolve(ps);
				});
				// return resolve([{"product_size_id":101,"product_size_name":"XL"},{"product_size_id":102,"product_size_name":"XXL"}]);
			});
		}
		function colorList(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from product_color",function(err,pcl){
					if(err) return reject([]);
					else return resolve(pcl);
				});

				// return resolve([{"product_color_id":301,"product_color_name":"Red"},{"product_color_id":302,"product_color_name":"Blue"}]);
			});
		}
		function brandList(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from product_brand",function(err,pb){
					if(err) return reject([]);
					else return resolve(pb);
				});
				// return resolve([{"product_brand_id":201,"product_brand_name":"Hollywood"},{"product_size_id":202,"product_size_name":"Bollywood"}]);
			});
		}
		
		
		Promise.all([itemTypeList(),productSize(),colorList(), brandList()]).then(function(data) {
			var list={
				itemTypeList:data[0],
				sizeList:data[1],
				colorList:data[2],
				brandList:data[3]
			};
	      	callback(null, list);
	    });
	},
	getFilterProductList:function(filterBy,callback){
		if(filterBy.tag_id || filterBy.seller_id || filterBy.searchby || filterBy.product_subcategory_id || filterBy.menu_subcategory_id || filterBy.menu_category_id || filterBy.product_category_id || filterBy.size || filterBy.color || filterBy.brand  )	 {
			FilterByProduct(filterBy);
		}else{
			db.query("Select count( * ) as  total_record from products p",function (err, total){
				if(err) {
					callback(null, {list:[],totalPages:0});
				}else{
					db.query("Select * from products p WHERE product_status != 'remove' LIMIT 12 OFFSET " + (filterBy.pageNumber * 12),  function (err, list) {
						if(err) {
							callback(null, {list:[],totalPages:0});
						} else{
							var totalPoducts = Math.ceil(total[0]['total_record'])
							var totalPage = Math.ceil(total[0]['total_record']/12 )
							callback(null, {productList:list,totalPoducts:totalPoducts,totalPages:totalPage});
						}
					});
				}
			});
		}
		
		function FilterByProduct(filterBy){
			var sqlQuery1 = '';
			var sorting = filterBy.sorting == 'Low Price' ?
			' ORDER BY products.actual_price ASC' : filterBy.sorting == 'High Price' ?
			' ORDER BY products.actual_price DESC' :
			' ORDER BY products.created_date DESC' ? filterBy.sorting == 'New' :
			' ORDER BY products.created_date ASC';
			var sqlQuery="select products.* from products  ";
			if(filterBy.size){
				sqlQuery=sqlQuery+ " INNER JOIN product_quantity ON product_quantity.product_id=products.product_id "
			}
			if(filterBy.color && !filterBy.size){
				sqlQuery=sqlQuery+ " INNER JOIN product_quantity ON product_quantity.product_id=products.product_id "
			}
			if(filterBy.tag_id){
				sqlQuery=sqlQuery+ " INNER JOIN product_tag_selected ON product_tag_selected.product_id=products.product_id "
			}
	
			if(filterBy.seller_id || filterBy.tag_id || filterBy.searchby || filterBy.product_subcategory_id || filterBy.menu_subcategory_id || filterBy.menu_category_id || filterBy.product_category_id || filterBy.size || filterBy.color || filterBy.brand  )	 {
				sqlQuery = sqlQuery+ " WHERE product_status != 'remove' AND ";
				filterBy.tag_id ? sqlQuery = sqlQuery+ " product_tag_selected.tag_id = " + filterBy.tag_id + " AND " : null;
				filterBy.size ? sqlQuery = sqlQuery+ " product_quantity.product_size_id = " + filterBy.size + " AND " : null;
				filterBy.color ? sqlQuery = sqlQuery+ " product_quantity.product_color_id = " + filterBy.color + " AND " : null;
				filterBy.brand ? sqlQuery = sqlQuery+ " products.product_brand_id = " + filterBy.brand + " AND " : null;
				filterBy.seller_id ? sqlQuery = sqlQuery+ " products.seller_id = " + filterBy.seller_id + " AND " : null;
				filterBy.product_category_id ? sqlQuery = sqlQuery+ " products.product_category_id = " + filterBy.product_category_id + " AND " : null;
				filterBy.menu_category_id ? sqlQuery = sqlQuery+ " products.menu_category_id = " + filterBy.menu_category_id + " AND " : null;
				filterBy.menu_subcategory_id ? sqlQuery = sqlQuery+ " products.menu_subcategory_id = " + filterBy.menu_subcategory_id + " AND " : null;
				filterBy.product_subcategory_id ? sqlQuery = sqlQuery+ " products.product_subcategory_id = " + filterBy.product_subcategory_id + " AND " : null;
				filterBy.searchby ? sqlQuery = sqlQuery+ " `product_name` LIKE '%" + filterBy.searchby + "%'  AND " : null;
				
				sqlQuery1 =	filterBy.sorting ? sqlQuery + " products.actual_price > 0 "+sorting+" " : sqlQuery + " products.actual_price > 0 ORDER BY product_id "
					
				sqlQuery =	filterBy.sorting ? sqlQuery + " products.actual_price > 0 "+sorting+" LIMIT 12 OFFSET " + (filterBy.pageNumber * 12) : sqlQuery + " products.actual_price > 0 ORDER BY product_id LIMIT 12 OFFSET " + (filterBy.pageNumber * 12)
			
				

				
			}
			console.log(sqlQuery)
			console.log("sqlQuerysqlQuerysqlQuerysqlQuerysqlQuery")
			console.log(sqlQuery1)
			
			db.query(sqlQuery,function(err,list){
				if(err) {
					callback(null, {list:[],totalPages:0});
				}
				else{
					if(list && list.length){
						db.query(sqlQuery1,function(err1,list1){
							if(err1) {
								console.log(err1);
							}else{
								console.log(list1.length);
								console.log(list.length);
								filterBy.pageNumber = filterBy.pageNumber == 0 ? filterBy.pageNumber +1 : filterBy.pageNumber;
								function paginate (array, page_size, page_number) {
									--page_number;
									return array.slice(page_number * page_size, (page_number + 1) * page_size);
								}
								callback(null, {
									//productList:paginate(list,4 ,filterBy.pageNumber),
									productList: (list),
									totalPoducts: (list1.length),
									totalPages:Math.ceil(list1.length / 12 )
								});
							}
						});
						
					}else{
						callback(null, {list:[],totalPages:0});
					}
					
					//var totalPage = Math.ceil(list[0]['total_record']/4 );
					//callback(null, {productList:list,totalPages:totalPage});
				}
			});
		}
		
		function FilterByProduct1(filterBy){
			var sqlQuery1 = "select products.*, COUNT(*) as total_record  from products ";
			var sqlQueryStart = "select products.* from products ";
			var sqlQuery = " ";
			if(filterBy.size){
				sqlQuery = sqlQuery+ " INNER JOIN product_quantity ON product_quantity.product_size_id=products.product_id "
	
			}
			if(filterBy.color){
				sqlQuery=sqlQuery+ " INNER JOIN product_quantity ON product_quantity.product_color_id=products.product_id "
	
			}
			if(filterBy.brand){
				//sqlQuery=sqlQuery+ " INNER JOIN product_brand ON product_brand.product_brand_id=products.product_id "
			}
	
			if(filterBy.size || filterBy.color || filterBy.brand  )	 {
				sqlQuery = sqlQuery+ " WHERE ";
				filterBy.size ? 
					sqlQuery = sqlQuery+ " product_size.product_size_id = " + filterBy.size + " AND " : null;
				filterBy.color ?
					sqlQuery = sqlQuery+ " product_color.product_color_id = " + filterBy.color + " AND " : null;
				filterBy.brand ?
					sqlQuery = sqlQuery+ " products.product_brand_id = " + filterBy.brand + " AND " : null;
	
				sqlQuery = sqlQuery + " products.after_discount_price > 0 ORDER BY product_id LIMIT 4   "
			}
			sqlQueryStart = sqlQuery1+ sqlQuery;
			db.query(sqlQueryStart,function(err,list){
				if(err) {
					callback(null, {list:[],totalPages:0});
				} else{
					var totalPage = Math.ceil(list[0]['total_record']/4 );
					callback(null, {productList:list,totalPages:totalPage});
				}
			});
		}
	}
};
module.exports=Filter;
