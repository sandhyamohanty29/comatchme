var db=require('../dbconnection');

var Category={
	getCategory:function(callback){
		return db.query("Select * from menu_category",callback);
	},

	getSubcategory:function(id,callback){
		return db.query("SELECT * from menu_subcategory where menu_category_id=?",[id],callback);
	},

	getSubCategoryProduct:function(id,callback){
		return db.query("SELECT * from product_category where menu_subcategory_id=?",[id],callback);
	},

	getSubProductList:function(id,callback){
		return db.query("SELECT * from product_subcategory where product_category_id=?",[id],callback);
	},

	getProductName:function(id,callback){
		return db.query("SELECT * from products where product_id=?",[id],callback);
	},

	getSellerName:function(id,callback){
		return db.query("SELECT * from seller_user where seller_id=?",[id],callback);
	},
	getProductRating:function(id, seller_id, customer_id, product_order_id, callback){
		return db.query("SELECT * from product_rating where product_id=? AND seller_id=? AND customer_id=? AND  product_order_id=?",[id,seller_id, customer_id, product_order_id],callback);
	},
	getCoustomerName:function(id,callback){
		return db.query("SELECT * from customer_user where customer_id=? ",[id],callback);
	}

};
module.exports=Category;
