var db=require('../dbconnection');

var Startup={
	createStartup:function(sqlquery, callback){
		return  db.query(sqlquery,callback);
	}

};
module.exports=Startup;
