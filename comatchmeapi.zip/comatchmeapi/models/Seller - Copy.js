var bcrypt = require('bcryptjs');
var db=require('../dbconnection');

var Seller={

getAllSellers:function(result){
    db.query("Select * from seller_user;", function (err, res) {
        
        if(err) {
            console.log("error: ", err);
            result(null, err);
        }
        else{
            console.log('sellers list is : ', res);  

            result(null, res);
        }
    });   
},
getSellerById:function(id, result){
    db.query("select * from seller_user where seller_id=?",[id], function (err, res) {
        
        if(err) {
            console.log("error: ", err);
            result(null, err);
        }
        else{
            console.log('seller is : ', res);  

            result(null, res);
        }
    });
},
registerSeller:function(Seller,result){
    var currentDateTime = new Date();
    db.query("Insert into seller_user set ?", Seller, function (err, res) {
        
        if(err) {
            console.log("error: ", err);
            result(null, err);
        }
        else{
            console.log('seller is : ', res);  

            result(null, res);
        }
    });
},
loginSeller:function(Seller, result){

    db.query("SELECT * FROM seller_user WHERE seller_email = ?",[Seller.seller_email], function (err, res) {
        if(err) {
            console.log("error: ", err);
            result(null, err);
        }
        else{
            console.log('login response : ', res);  

            result(null, res);
        }
        
    });
},
deleteSeller:function(id,callback){
    return db.query("delete from seller_user where seller_id=?",[id],callback);
},
updateSeller:function(id,Seller,callback){
    return  db.query("update seller_user set seller_company = ?  where seller_id=?",[Seller.seller_company,id],callback);
},
// deleteAll:function(item,callback){

// var delarr=[];
//    for(i=0;i<item.length;i++){

//        delarr[i]=item[i].Id;
//    }
//    return db.query("delete from seller_user where seller_id in (?)",[delarr],callback);
// }
};
module.exports=Seller;