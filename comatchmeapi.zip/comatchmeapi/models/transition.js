var db=require('../dbconnection');

var Transition={
	getBestSeller:function(callback){
		return db.query("SELECT * from products WHERE product_status != 'remove' ORDER BY created_date DESC LIMIT 12",callback);
	},

	getLatestProduct:function(id,callback){
		return db.query("SELECT * from products WHERE product_status != 'remove' ORDER BY created_date DESC LIMIT 12",callback);
	},

	getProductFavirate:function(product_id,customer_id,callback){
		return db.query("SELECT * from favourite_product where product_id=? and customer_id=? ",[product_id, customer_id],callback);
	},

	getSellerFavirate:function(seller_id,customer_id,callback){
		return db.query("SELECT * from favourite_shop where seller_id=? and customer_id=? ",[seller_id, customer_id],callback);
	}
};
module.exports=Transition;
