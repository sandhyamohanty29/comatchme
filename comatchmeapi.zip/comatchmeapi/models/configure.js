var express = require('express');

 var sgMail = require('@sendgrid/mail');
 sgMail.setApiKey('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');
  var nodemailer = require('nodemailer');

var db=require('../dbconnection');

var configure={

	comman_sql_query:function(sqlquery, callback){
		return  db.query(sqlquery,callback);
	},
	
	update_content:function(data, callback){
		//return  db.query("update veggmi_public_content set content = ?  where content_id=?",[data.content,data.content_id],callback);
		return  db.query("update veggmi_public_content set content = 'ok'  where content_id= 2",callback);
	},

	
	
	sendemail:function(data, callback){
		var h1 ='<div style="width:100%;margin:0 auto;"><div style="box-shadow: 0px 4px 12px #CDCDCD;"><div style="background:#e9f0f2;padding:40px 0;text-align:center;color:#fff;"><a href=""><img src="https://www.comatchme.com/assets/images/favicon.png" style="width: 222px;"></a></div>';
	     var h3='<div style="background: #b7eadb;padding: 30px 0;text-align: center;float: left;width: 100%;"><h4 style="font-size:20px;color:#141211;font-weight:300;margin:0;">Copyright 2017. All Rights Reserved</h4><ul style="list-style:none;margin-top:15px;padding:0;margin-bottom: 0;"><li style="display:inline-block;margin:5px 14px 0 14px;"></li><li style="display:inline-block;margin:5px 14px 0 0;"></li><li style="display:inline-block;margin:5px 14px 0 0;"></li></ul></div></div></div>';
		
		let mailOptions = {
			from: 'comatch@info.com', // sender address
			to: data.body.email, // list of receivers 'test@example.com, test1@example.com'
			subject: data.body.subject, // Subject line
			text: 'Welcome to comatch', // plain text body
			html:  h1+data.body.html+h3 // html body
		
		};
		console.log(mailOptions);
		var sentmail = sgMail.send(mailOptions);
		if(sentmail){
			console.log('sent');
		}else{
			console.log('not sent');
		}
		/* transporter.sendMail(mailOptions, (error, info) => {
			if (error) {
				console.log('error');
				console.log(error);
				return (error);
			}else{
				console.log('Message sent: %s', info.messageId);
				return info.messageId;
			}
		}); */
		
		
		console.log('====================');
		
		
	}, 
	
	getProductMetaDataDetails1:function(ProductMetaTableObject, result){
		var tableArray = {};
		db.query("select * from " + ProductMetaTableObject.tableName,  function (err, res) {
			
				if(err) {
					console.log("error: ", err);
					result(null, err);
				}
				else{
					var parsedRows = JSON.parse(JSON.stringify(res));
					tableArray[ProductMetaTableObject.tableName] = parsedRows;
					result(null, ProductMetaTableObject.tableName, tableArray);
				}
			});

	}, 
	
	getProductMetaDataDetails:function(callback){
		function menu_category(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from menu_category",function(err,pc){
					if(err) return reject([]);
					else return resolve(pc);
				});
			});
		}
		function menu_subcategory(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from menu_subcategory",function(err,pc){
					if(err) return reject([]);
					else return resolve(pc);
				});
			});
		}
		function product_category(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from product_category",function(err,pc){
					if(err) return reject([]);
					else return resolve(pc);
				});
			});
		}
		function product_subcategory(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from product_subcategory",function(err,pc){
					if(err) return reject([]);
					else return resolve(pc);
				});
			});
		}
		function product_size(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from product_size",function(err,ps){
					if(err) return reject([]);
					else return resolve(ps);
				});
			});
		}
		function product_color(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from product_color",function(err,pcl){
					if(err) return reject([]);
					else return resolve(pcl);
				});
			});
		}
		function product_brand(){
			return new Promise(function(resolve, reject) {
				db.query("Select * from product_brand",function(err,pb){
					if(err) return reject([]);
					else return resolve(pb);
				});
			});
		}
		
		Promise.all([menu_category(),menu_subcategory(),product_category(),product_subcategory(),product_color(),product_size(), product_brand()]).then(function(data) {
			var list={
				menu_category:data[0],
				menu_subcategory:data[1],
				product_category:data[2],
				product_subcategory:data[3],
				product_color:data[4],
				product_size:data[5],
				product_brand:data[6]
			};
	      	callback(null, list);
	    });

	}
};

module.exports=configure;


	