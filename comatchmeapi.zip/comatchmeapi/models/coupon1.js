var db=require('../dbconnection');

var Coupon={

getCoupon:function(Coupon,callback){
    return db.query("select * from product_coupon where coupon_code = '"+Coupon+"' And coupon_status = 'active'",callback);
    }
};
module.exports=Coupon;