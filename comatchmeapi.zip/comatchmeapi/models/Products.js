var db=require('../dbconnection');

var Products={

getAllProducts:function(callback){
	return db.query("Select * from products p",callback);
},

getProductById:function(id,callback){
    return db.query("SELECT * from products where id=?",[id],callback);
},
addProduct:function(Products, callback){
		return db.query("Insert into products (productName,productDesc,price,category,subcategory) values(?,?,?,?,?)",
				[Products.productName,Products.productDesc,Products.price,Products.category,Products.subcategory],callback);
}

};


module.exports=Products;