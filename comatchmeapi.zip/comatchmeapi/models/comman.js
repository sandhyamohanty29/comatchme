var db=require('../dbconnection');

var comman={

	addUser:function(Registration,callback){
	   console.log("inside service");
	   console.log(Registration.id);
		return db.query("Insert into customer_user (full_name,customer_pass,customer_status, customer_verification_code) values(?,?,?,?)",
					[Registration.full_name,Registration.customer_pass,'active','123456'],callback);
	}
};
module.exports=Registration;