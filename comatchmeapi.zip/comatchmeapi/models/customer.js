var db=require('../dbconnection');

var customer={

	customer_register:function(data,callback){
	   console.log("inside service1");
	   return db.query("Insert into customer_user (full_name,customer_pass,customer_status, customer_verification_code,'created_date') values(?,?,?,?)",
					[data.full_name,data.customer_pass,'active','123456'],callback);
	}
};

module.exports=customer;