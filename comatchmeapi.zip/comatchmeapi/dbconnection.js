var mysql=require('mysql');

/*
var db_config = {
	host: 'localhost',
    user: 'root',
    password: '',
    database: 'catchme'

};*/
/**/

/**/ var db_config = {
	connectionLimit : 10,
	host: 'sql12.freemysqlhosting.net',
    user: 'sql12273351',
    password: 'Y6R3RJmNqL',
    database: 'sql12273351',
	port:'3306'
};



/* 
var db_config = {
	connectionLimit : 5,
	host: 'db4free.net',
    user: 'veggmi_test',
    password: 'veggmi_test',
    database: 'veggmi_test',
	port:'3306'
};
var db_config = {
	connectionLimit : 10,
	host:'166.62.28.109:3306',
	user:'zzz_charity9',
	password:'zzz_charity9',
	database:'zzz_charity9',
	port:'3306'
};*/
/**
 var db_config = {
  connectionLimit : 10,
      host:'sql12.freemysqlhosting.net',
      user:'sql12269997',
      password:'1cx9L7qnXQ',
      database:'sql12269997',
      port:'3306'
    };**/
    var pool = mysql.createPool(db_config);
/*
//         connectionLimit : 100,
//         waitForConnections : true,
//         queueLimit :0,
//         debug    :  true,
//         wait_timeout : 28800,
//         connect_timeout :10
// */
// var connection;

// function handleDisconnect() {
//   connection = mysql.createPool(db_config); // Recreate the connection, since
//                                                   // the old one cannot be reused.

//   connection.connect(function(err) {              // The server is either down
//     if(err) {                                     // or restarting (takes a while sometimes).
//       console.log('error when connecting to db:', err);
//       setTimeout(handleDisconnect, 2000); // We introduce a delay before attempting to reconnect,
//     }                                     // to avoid a hot loop, and to allow our node script to
//   });                                     // process asynchronous requests in the meantime.
//                                           // If you're also serving http, display a 503 error.
//   connection.on('error', function(err) {
//     console.log('db error', err.code);
//     if(err.code == 'PROTOCOL_CONNECTION_LOST') { 
//       connection.destroy();// Connection to the MySQL server is usually
//       handleDisconnect();
//       console.log('connection made')                         // lost due to either server restart, or a
//     } else {                                      // connnection idle timeout (the wait_timeout
//       throw err;                                  // server variable configures this)
//     }
//   });
// }

// handleDisconnect();


// /* 
// var connection = mysql.createConnection({
// 	host:'localhost',
// 	user:'root',
// 	password:'',
// 	database:'veggmi'
// });*/
// /*
// var connection=mysql.createConnection({
// 	host:'166.62.28.109',
// 	user:'zzz_charity9',
// 	password:'zzz_charity9',
// 	database:'zzz_charity9',
// 	port:'3306'
// });*/
// /*send grid apikey: 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*/
// module.exports=connection;

module.exports = connection = {
  query: function () {
      var queryArgs = Array.prototype.slice.call(arguments),
          events = [],
          eventNameIndex = {};

      pool.getConnection(function (err, conn) {
          if (err) {
			  console.log('error connecting database', err);
              if (eventNameIndex.error) {
                  eventNameIndex.error();
              }
          }
          if (conn) { 
              var q = conn.query.apply(conn, queryArgs);
              q.on('end', function () {
                  conn.release();
              });

              events.forEach(function (args) {
                  q.on.apply(q, args);
              });
          }
      });

      return {
          on: function (eventName, callback) {
              events.push(Array.prototype.slice.call(arguments));
              eventNameIndex[eventName] = callback;
              return this;
          }
      };
  }
};