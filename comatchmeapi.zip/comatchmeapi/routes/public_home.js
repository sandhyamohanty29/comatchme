var express = require('express');
var router = express.Router();
var configure=require('../models/configure');
var bcrypt = require('bcryptjs');
var _ = require('lodash');  


router.post('/add_user',function(req,res,next){
	var sqlquery = "INSERT INTO `user_registration` (`first_name`, `last_name`, `country_name`, `city_name`) VALUES ('"+req.body.first_name+"', '"+req.body.last_name+"', '"+req.body.country_name+"', '"+req.body.city_name+"')";
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Data not found" });
        } else{
            res.send({ "status":200, "data":rows, "message":"User registeration Successfully" });
        }
    });
	
});

module.exports=router;