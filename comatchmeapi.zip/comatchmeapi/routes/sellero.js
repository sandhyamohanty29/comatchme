var express = require('express');
var router = express.Router();
var configure=require('../models/configure');
var Category=require('../models/category');
var bcrypt = require('bcryptjs');
var _ = require('lodash');

router.post('/addSeller',function(req,res,next){
	
	var sqlquery = "select * from seller_user where seller_email = '"+req.body.seller_email+"'";
	
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Email id already exist1." });
        }else{
            var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				res.send({ "status":201, "message":"Email id already exist." });
			}else{
				
				var verificateion_code = "";
				var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
				for (var i = 0; i < 25; i++){
					verificateion_code += possible.charAt(Math.floor(Math.random() * possible.length));
				}
				var seller_password = bcrypt.hashSync(req.body.seller_password, 10);
				
				var sqlquery = "INSERT INTO `seller_user` (`seller_name`, `seller_email`, `seller_company`, `company_desc`, `seller_password`, `created_date`, `created_time`,  `verification_code`, `seller_image`, `seller_banner`) VALUES ('"+req.body.seller_name+"', '"+req.body.seller_email+"', '"+req.body.seller_company+"', '"+req.body.company_desc+"',  '"+seller_password+"', '"+req.body.created_date+"', '"+req.body.created_time+"', '"+verificateion_code+"', '"+req.body.seller_image+"', 'defautbanner1.png')";
				console.log(sqlquery);
				configure.comman_sql_query(sqlquery,function(err,rows){
					if(err) {
						res.send({ "status":201,  "err":err,"message":"Something wend wrong. Please try again" });
					} else{
						var seller_name= (req.body.seller_name);
						req.body.email = req.body.seller_email;
						req.body.subject = 'Veggmi verificateion email';
						req.body.html = '<div style="background:#f5f8fa;padding: 25px 25px 60px;"><h3 style="font-size:30px;color:#151917;text-transform:uppercase;font-weight:500;margin-top:20px;margin-bottom: 0;">Hello '+seller_name+',</h3><p style="font-size:18px;color:#757d83;margin: 40px 0;"><strong style="font-size:18px;color:#757d83;display:block;font-weight:400;">Thank you for signing up for Veggmi!</strong>Welcome to the worldwide community of vegan people.Please verify your email address with the link below to get started. You will only need to do this once.</p><a href="http://veggmi.xyz/seller-verify/'+verificateion_code+'">Click Here</a><h6 style="font-size:18px;color:#757d83;margin: 30px 0;font-weight:400;">If the link doesn&#39;t work, try copying and pasting it in your browser address bar.</h6><h5 style="font-size:16px;font-weight:400;color:#242424;line-height:30px;margin-bottom: 0;"><strong style="font-weight:400;display: block;line-height">Thank You,</strong>The Veggmi Team</h5></div>';
						configure.sendemail(req,function(err,rows){});
						res.send({ "status":200, "data":rows, "message":"Your account has been created successfully. Please login to continue." });
					}
				});
			}
		}
	});
});


router.post('/check_seller_auth',function(req,res,next){
	var sqlquery = "select * from seller_user where seller_status = 'active' AND seller_email = '"+req.body.seller_email+"'";
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Invalid Email or account not activated yet." });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
                if(bcrypt.compareSync(req.body.seller_password, result[0].seller_password)){
					res.send({ "status":200, "data":result, "message":"Login Successfully " });
                  
                } else{
					res.send({ "status":201, "data":result, "message":"Invalid Password" });
                }
            } else{
                res.send({ "status":201, "data":result, "message":"Invalid seller login details" });
            }
        }
    });
	
});

router.post('/check_seller_changepass_auth',function(req,res,next){
	var sqlquery = "SELECT * FROM `seller_user` WHERE `seller_id` = "+req.body.seller_id;
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":" something wrong " });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			console.log(rows);
			console.log(_.size(result));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
                if(bcrypt.compareSync(req.body.old_pass, result[0].seller_password)){
				var seller_password = bcrypt.hashSync(req.body.new_pass, 10);
                var query = "UPDATE `seller_user` SET `seller_password` = '"+seller_password+"' WHERE `seller_user`.`seller_id` = "+req.body.seller_id;
				configure.comman_sql_query(query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						
						res.send({ "status":200, "data":rows, "message":"Password updated Successfully" });
					}
				});
				  
                } else{
					res.send({ "status":201, "data":result, "message":"Invalid old Password" });
                }
            } else{
                res.send({ "status":201, "data":result, "message":"Something went wrong, try again." });
            }
        }
    });
	
});

router.post('/check_user_changepass_auth',function(req,res,next){
	var sqlquery = "SELECT * FROM `customer_user` WHERE `customer_id` = "+req.body.customer_id;
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":" something wrong " });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			console.log(rows);
			console.log(_.size(result));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
                if(bcrypt.compareSync(req.body.old_pass, result[0].customer_pass)){
				var customer_pass = bcrypt.hashSync(req.body.new_pass, 10);
                var query = "UPDATE `customer_user` SET `customer_pass` = '"+customer_pass+"' WHERE `customer_user`.`customer_id` = "+req.body.customer_id;
				configure.comman_sql_query(query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						
						res.send({ "status":200, "data":rows, "message":"Password updated Successfully" });
					}
				});
				  
                } else{
					res.send({ "status":201, "data":result, "message":"Invalid old Password" });
                }
            } else{
                res.send({ "status":201, "data":result, "message":"Something went wrong, try again." });
            }
        }
    });
	
});

router.post('/seller_forgetpassword',function(req,res,next){
	
	var sqlquery = "select * from seller_user where seller_email = '"+req.body.seller_email+"'";
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Invalid email" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				/*Insert new verification_code*/
				var verification_code = 'ss';
				var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
				for (var i = 0; i < 25; i++){
					verification_code += possible.charAt(Math.floor(Math.random() * possible.length));
				}
				var insert_veroif_query = "UPDATE `seller_user` SET `verification_code` = '"+verification_code+"' WHERE `seller_id` = "+result[0].seller_id;
				configure.comman_sql_query(insert_veroif_query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						 /*send forget password email*/
						var seller_name= (result[0].seller_name);
						req.body.email = result[0].seller_email;
						req.body.subject = 'Veggmi Password Reset';
						req.body.html ='<div style="background:#f5f8fa;padding: 25px 25px 60px;"><h3 style="font-size:30px;color:#151917;text-transform:uppercase;font-weight:500;margin-top:20px;margin-bottom: 0;">Hello '+seller_name+',</h3><p style="font-size:18px;color:#757d83;margin: 40px 0;">We received a request to reset your Veggmi password. Please click the link below to set a new password for your Veggmi account:</p><a href="http://veggmi.xyz/resetpassword/'+verification_code+'" style="font-size:17px;color:#0095ff;">RESET PASSWORD LINK</a><h5 style="font-size:16px;font-weight:400;color:#242424;line-height:30px;margin-bottom: 0;"><strong style="font-weight:400;display: block;line-height">Thank You,</strong>The Veggmi Team</h5></div>';
                        configure.sendemail(req,function(err,rows){});
						res.send({ "status":200, "data":rows, "message":"Rest password email sent Successfully" });
					}
				});
               
            } else{
                res.send({ "status":201, "data":result, "message":"Invalid Email" });
            }
        }
    });
	
});

router.post('/user_forgetpassword',function(req,res,next){
	
	var sqlquery = "select * from customer_user where customer_email = '"+req.body.customer_email+"'";
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Invalid email" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				/*Insert new verification_code*/
				var verification_code = 'ss';
				var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
				for (var i = 0; i < 25; i++){
					verification_code += possible.charAt(Math.floor(Math.random() * possible.length));
				}
				var insert_veroif_query = "UPDATE `customer_user` SET `customer_verification_code` = '"+verification_code+"' WHERE `customer_id` = "+result[0].customer_id;
				configure.comman_sql_query(insert_veroif_query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						 /*send forget password email*/
						 var full_name= (result[0].full_name);
						req.body.email = result[0].customer_email;
						req.body.subject = 'Veggmi Password Reset';
						req.body.html ='<div style="background:#f5f8fa;padding: 25px 25px 60px;"><h3 style="font-size:30px;color:#151917;text-transform:uppercase;font-weight:500;margin-top:20px;margin-bottom: 0;">Hello '+full_name+',</h3><p style="font-size:18px;color:#757d83;margin: 40px 0;">We received a request to reset your Veggmi password. Please click the link below to set a new password for your Veggmi account:</p><a href="http://veggmi.xyz/customer-resetpassword/'+verification_code+'" style="font-size:17px;color:#0095ff;">RESET PASSWORD LINK</a><h5 style="font-size:16px;font-weight:400;color:#242424;line-height:30px;margin-bottom: 0;"><strong style="font-weight:400;display: block;line-height">Thank You,</strong>The Veggmi Team</h5></div>';
						configure.sendemail(req,function(err,rows){});
						res.send({ "status":200, "data":rows, "message":"Rest password email sent Successfully" });
					}
				});
               
            } else{
                res.send({ "status":201, "data":result, "message":"Invalid Email" });
            }
        }
    });
	
});

router.post('/seller_resetpassword',function(req,res,next){
	
	var sqlquery = "select * from seller_user where verification_code = '"+req.body.verification_code+"'";
	
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Verification code either expire or wrong" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				/*Insert new password*/
				
				var seller_password = bcrypt.hashSync(req.body.new_password, 10);
				
				var insert_veroif_query = "UPDATE `seller_user` SET `seller_password` = '"+seller_password+"' WHERE `seller_id` = "+result[0].seller_id;
				configure.comman_sql_query(insert_veroif_query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						res.send({ "status":200, "data":rows, "message":"Password update Successfully" });
					}
				});
               
            } else{
				res.send({ "status":201, "message":"Verification code either expire or wrong" });
            }
        }
    });
	
});

router.post('/user_resetpassword',function(req,res,next){
	
	var sqlquery = "select * from customer_user where customer_verification_code = '"+req.body.verification_code+"'";
	
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Verification code either expire or wrong" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				/*Insert new password*/
				
				var customer_pass = bcrypt.hashSync(req.body.new_password, 10);
				
				var insert_veroif_query = "UPDATE `customer_user` SET `customer_pass` = '"+customer_pass+"' WHERE `customer_id` = "+result[0].customer_id;
				configure.comman_sql_query(insert_veroif_query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						res.send({ "status":200, "data":rows, "message":"Password update Successfully" });
					}
				});
               
            } else{
				res.send({ "status":201, "message":"Verification code either expire or wrong" });
            }
        }
    });
	
});

router.post('/user_verify',function(req,res,next){
	
	var sqlquery = "select * from customer_user where customer_verification_code = '"+req.body.verification_code+"'";
	
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Verification code either expire or wrong" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				/*Insert new password*/
				var customer_verification_code = "";
				var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

				for (var i = 0; i < 25; i++){
					customer_verification_code += possible.charAt(Math.floor(Math.random() * possible.length));
				}
				var insert_veroif_query = "UPDATE `customer_user` SET `customer_status` = 'active', `customer_verification_code` = '"+customer_verification_code+"' WHERE `customer_id` = "+result[0].customer_id;
				configure.comman_sql_query(insert_veroif_query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						res.send({ "status":200, "data":rows, "message":"account activate update Successfully" });
					}
				});
               
            } else{
				res.send({ "status":201, "message":"Verification code either expire or wrong" });
            }
        }
    });
	
});


router.post('/seller_verify',function(req,res,next){
	
	var sqlquery = "select * from seller_user where verification_code = '"+req.body.verification_code+"'";
	
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Verification code either expire or wrong" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				/*Insert new password*/
				var verification_code = "";
				var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

				for (var i = 0; i < 25; i++){
					verification_code += possible.charAt(Math.floor(Math.random() * possible.length));
				}
				var insert_veroif_query = "UPDATE `seller_user` SET `seller_status` = 'active' , `verification_code` = '"+verification_code+"' WHERE `seller_id` = "+result[0].seller_id;
				configure.comman_sql_query(insert_veroif_query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						res.send({ "status":200, "data":rows, "message":"Account activate update Successfully" });
					}
				});
               
            } else{
				res.send({ "status":201, "message":"Verification code either expire or wrong" });
            }
        }
    });
	
});

router.post('/adduser',function(req,res,next){
	
	var sqlquery = "select * from customer_user where customer_email = '"+req.body.customer_email+"'";
	
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Email id already exist1." });
        }else{
            var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				res.send({ "status":201, "message":"Email id already exist." });
			}else{
				
				var customer_verification_code = "";
				var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

				for (var i = 0; i < 25; i++){
					customer_verification_code += possible.charAt(Math.floor(Math.random() * possible.length));
				}
				var customer_pass = bcrypt.hashSync(req.body.customer_pass, 10);
				
				var sqlquery = "INSERT INTO `customer_user` (`full_name`, `lname`, `customer_email`, `customer_pass`, `customer_verification_code`, `created_date`, `created_time`) VALUES ('"+req.body.full_name+"', '"+req.body.lname+"', '"+req.body.customer_email+"',  '"+customer_pass+"', '"+customer_verification_code+"', '"+req.body.created_date+"', '"+req.body.created_time+"')";
				
				configure.comman_sql_query(sqlquery,function(err,rows){
					if(err) {
						res.send({ "status":201,  "err":err,"message":"Something wend wrong. Please try again" });
					} else{
						console.log(customer_verification_code);
						console.log("===========");
						var customer_name= (req.body.full_name);
						req.body.email = req.body.customer_email;
						req.body.subject = 'Veggmi verificateion email';
						//req.body.html = 'hvgh';
						req.body.html = '<div style="background:#f5f8fa;padding: 25px 25px 60px;"><h3 style="font-size:30px;color:#151917;text-transform:uppercase;font-weight:500;margin-top:20px;margin-bottom: 0;">Hello '+customer_name+',</h3><p style="font-size:18px;color:#757d83;margin: 40px 0;"><strong style="font-size:18px;color:#757d83;display:block;font-weight:400;">Thank you for signing up for Veggmi!</strong><span>Welcome to the worldwide community of vegan people. Please verify your email address with the link below to get started. You will only need to do this once.</span></p><a href="http://veggmi.xyz/customer-verify/'+customer_verification_code+'"> Click Here</a><h6 style="font-size:18px;color:#757d83;margin: 30px 0;font-weight:400;">If the link doesn&#39;t work, try copying and pasting it in your browser address bar.</h6><h5 style="font-size:16px;font-weight:400;color:#242424;line-height:30px;margin-bottom: 0;"><strong style="font-weight:400;display: block;line-height">Thank You,</strong>The Veggmi Team</h5></div>';
						configure.sendemail(req,function(err,rows){});
						res.send({ "status":200, "data":rows, "message":"Your account has been created successfully. Please please verify email." });
					}
				});
			}
		}
	});
});
router.post('/resend_mail',function(req,res,next){
	 var sqlquery = "select * from customer_user where customer_email = '"+req.body.customer_email+"'";
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
		console.log(rows);
         if(err) {
            res.send({ "status":201, "message":"something wrong." });
        }else{
						var customer_name= (req.body.full_name);
						req.body.email = req.body.customer_email;
						req.body.subject = 'Veggmi verificateion email';
						req.body.html = '<div style="background:#f5f8fa;padding: 25px 25px 60px;"><h3 style="font-size:30px;color:#151917;text-transform:uppercase;font-weight:500;margin-top:20px;margin-bottom: 0;">Hello '+customer_name+',</h3><p style="font-size:18px;color:#757d83;margin: 40px 0;"><strong style="font-size:18px;color:#757d83;display:block;font-weight:400;">Thank you for signing up for Veggmi!</strong>Welcome to the worldwide community of vegan people.Please verify your email address with the link below to get started. You will only need to do this once.</p><a href="http://veggmi.xyz/customer-verify/'+rows[0].customer_verification_code+'">Click Here</a><h6 style="font-size:18px;color:#757d83;margin: 30px 0;font-weight:400;">If the link doesn&#39;t work, try copying and pasting it in your browser address bar.</h6><h5 style="font-size:16px;font-weight:400;color:#242424;line-height:30px;margin-bottom: 0;"><strong style="font-weight:400;display: block;line-height">Thank You,</strong>The Veggmi Team</h5></div>';
						configure.sendemail(req);
						res.send({ "status":200, "data":rows, "message":"Your account has been created successfully. Please please verify email." });
					 
        }
    });
});

router.post('/resend_seller_mail',function(req,res,next){
	 var sqlquery = "select * from seller_user where seller_email = '"+req.body.seller_email+"'";
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
		console.log(rows);
         if(err) {
            res.send({ "status":201, "message":"something wrong." });
        }else{
						var seller_name= (req.body.seller_name);
						req.body.email = req.body.seller_email;
						req.body.subject = 'Veggmi verificateion email';
						req.body.html = '<div style="background:#f5f8fa;padding: 25px 25px 60px;"><h3 style="font-size:30px;color:#151917;text-transform:uppercase;font-weight:500;margin-top:20px;margin-bottom: 0;">Hello '+seller_name+',</h3><p style="font-size:18px;color:#757d83;margin: 40px 0;"><strong style="font-size:18px;color:#757d83;display:block;font-weight:400;">Thank you for signing up for Veggmi!</strong>Welcome to the worldwide community of vegan people.Please verify your email address with the link below to get started. You will only need to do this once.</p><a href="http://veggmi.xyz/customer-verify/'+rows[0].verification_code+'">Click Here</a><h6 style="font-size:18px;color:#757d83;margin: 30px 0;font-weight:400;">If the link doesn&#39;t work, try copying and pasting it in your browser address bar.</h6><h5 style="font-size:16px;font-weight:400;color:#242424;line-height:30px;margin-bottom: 0;"><strong style="font-weight:400;display: block;line-height">Thank You,</strong>The Veggmi Team</h5></div>';
						configure.sendemail(req);
						res.send({ "status":200, "data":rows, "message":"Your account has been created successfully. Please please verify email." });
					 
        }
    });
});

router.get('/sendemailnewtest',function(req,res,next){
	var sqlquery = "select * from customer_user";
	console.log(sqlquery);
	configure.sendemail(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "data":err,"message":"Invalid  login details" });
        } else{
			res.send({ "status":201, "data":rows, "message":"Invalid customer Email" });
            
        }
    });
});

router.post('/check_user_auth',function(req,res,next){
	

	var sqlquery = "select * from customer_user where 	customer_status = 'active' AND  customer_email = '"+req.body.customer_email+"'";
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Invalid Email or account not activated yet." });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
                if(bcrypt.compareSync(req.body.customer_pass, result[0].customer_pass)){
					res.send({ "status":200, "data":result, "message":"Successfully  Login" });
                  
                } else{
					res.send({ "status":201, "data":result, "message":"Invalid customer Password" });
                }
            } else{
                res.send({ "status":201, "data":result, "message":"Invalid  login details" });
            }
        }
    });
	
});

router.post('/get_all_product_list',function(req,res,next){
	
	var sqlquery = "SELECT *, products.product_id, SUM(product_quantity.product_quantity) AS product_quantity_remaining FROM `products` left outer JOIN product_quantity ON (products.product_id =product_quantity.product_id) WHERE products.seller_id= '"+req.body.seller_id+"' AND products.product_status != 'remove' group by products.product_id";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/get_letest_product_list',function(req,res,next){
	
	var sqlquery = "SELECT * FROM `products`  WHERE product_status != 'remove'  AND `seller_id` = '"+req.body.seller_id+"' ORDER BY created_date DESC  LIMIT 3";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/get_letest_order_list',function(req,res,next){
	
	var sqlquery = "select * from product_order_details WHERE `seller_id` = '"+req.body.seller_id+"' ORDER BY created_date DESC  LIMIT 3";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
		
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
			if(rows.length > 0){
				
				rows.map(function(data,index){
					Category.getProductName(data.product_id,function(err,sub){
						if(sub.length > 0){
							rows[index]['product_name']=sub[0].product_name ;
							rows[index]['product1']= 1;
						}else{
							rows[index]['product_name']= 'Removed';
							rows[index]['product1']= 0;
						}
						
						if(rows.length == index+1){
							rows.map(function(data,index){
								Category.getCoustomerName(data.customer_id,function(err,sub1){
									if(sub1.length > 0){
										rows[index]['full_name']=sub1[0].full_name ;
										rows[index]['customer_1']= 1;
									}else{
										rows[index]['full_name']= 'Removed';
										rows[index]['customer_1']= 0;
									}
									if(rows.length == index+1){
										res.send({ "status":200, "data":rows, "message":"Fatched Successfully" }); 
									}
								});
							});
						}
					});
				});
			}else{
				res.send({ "status":200, "data":rows, "message":"Fatched Successfully" }); 
			}
		}
    });
});
router.post('/get_all_coupon_list',function(req,res,next){
	
	var sqlquery = "SELECT * FROM `product_coupon` WHERE coupon_status != 'remove'  AND `seller_id` = '"+req.body.seller_id+"'";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/product_detail_by_id',function(req,res,next){
	
	var sqlquery = "SELECT * FROM `products` WHERE  product_id = "+req.body.product_id+" AND seller_id = "+req.body.seller_id;	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Product Not found" });
        } else{
			var sqlquery1 = "SELECT * FROM `product_quantity` WHERE  product_id = "+req.body.product_id;	
			configure.comman_sql_query(sqlquery1,function(err,rows1){
				if(err) {
					res.send({ "status":201, "err":err, "message":"Something went wrong" });
				} else{
					var sqlquery1 = "SELECT * FROM `product_faqs` WHERE  product_id = "+req.body.product_id;	
					configure.comman_sql_query(sqlquery1,function(err,faqs){
						if(err) {
							res.send({ "status":201, "err":err, "message":"Something went wrong" });
						} else{
							res.send({ "status":200, "data":rows,"data1":rows1,"faq":faqs, "message":"Fatched Successfully" });
						}
					});
				}
			});
        }
    });
});

router.post('/remove_product_seller',function(req,res,next){
	
	var sqlquery = "update products set product_status = '"+req.body.product_status+"'   where product_id= "+req.body.product_id;;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Deleted Successfully" });
        }
    });
});

router.post('/products/metadata1',function(req,res,next){
    var metaDataResponseArray = [];
    var metaDataResponseArray1 = [];
    var metaDataRequestPayload = req.body;
    var isError = false;
    var errDesc;
    if(metaDataRequestPayload.length > 0){
        for(i=0; i<metaDataRequestPayload.length; i++){
            var metaDataObject = metaDataRequestPayload[i];
            if(!isError) {
                configure.getProductMetaDataDetails(metaDataObject,function(err,rows){
                    
                    if(err) {
                        isError = true;
                        errDesc = err;
                    } else{
                        metaDataResponseArray1.push(rows);
						metaDataResponseArray[metaDataObject.tableName] = rows;
                        console.log('metaDataResponseArray.length');
                        console.log(metaDataResponseArray);
                        console.log(metaDataResponseArray1.length);
                        if(metaDataResponseArray1.length === metaDataRequestPayload.length) {
                            //res.json(metaDataResponseArray);
                            res.send({ "status":200, "data":metaDataResponseArray, "message":"Deleted Successfully" });
						}
                    }
                });
            }            
        }
              
    }
});


router.post('/products/metadata',function(req,res,next){
    configure.getProductMetaDataDetails(function(err,rows){
        if(err){ console.log('err');  console.log(err);res.json(err); }
        else{ console.log('rows');  console.log(rows); res.json(rows); }
    });
});

router.post('/get_all_blog_list',function(req,res,next){
	
	var sqlquery = "SELECT * FROM `veggmi_add_blog`";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
			rows.map(function(data,index){
                var blog_heading_url = (data.blog_heading).toLowerCase().replace(/[^a-zA-Z0-9]/g,'-');
				rows[index]['blog_heading_url']=blog_heading_url;
           });
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
		console.log(rows);
    });
});

router.post('/get_all_blog_detail',function(req,res,next){
	
	var sqlquery = "SELECT * FROM `veggmi_add_blog` WHERE `blog_id` = "+req.body.blog_id+"";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/get_all_blog_by_limit',function(req,res,next){
	
	var sqlquery = "SELECT * FROM `veggmi_add_blog` LIMIT 4";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
			rows.map(function(data,index){
                var blog_heading_url = (data.blog_heading).toLowerCase().replace(/[^a-zA-Z0-9]/g,'-');
				rows[index]['blog_heading_url']=blog_heading_url;
           });
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/insert_comment',function(req,res,next){
	
var sqlquery = "INSERT INTO `blog_comment` (`user_id`, `user_name`, `user_image`, `user_comment`, `user_blog_id`, `user_type`, `user_email`, `created_date`, `created_time`) VALUES ('"+req.body.user_id+"','"+req.body.user_name+"','"+req.body.user_image+"','"+req.body.user_comment+"','"+req.body.user_blog_id+"', '"+req.body.user_type+"', '"+req.body.user_email+"', '"+req.body.created_date+"','"+req.body.created_time+"')";
	
	 
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Successfully submitted" });
        }
    });
});



router.post('/get_all_blog_comment',function(req,res,next){
	
	var sqlquery = "SELECT * FROM `blog_comment` WHERE `user_blog_id` = "+req.body.blog_id+"";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/add_coupon', function(req, res, next) {
    const data = req.body
	var coupon_id = 0;
    if (data.coupon_id == 0) {
        var sqlquery = `INSERT INTO product_coupon ( coupon_code, seller_id, valid_start, valid_end, coupon_status, coupon_discount) VALUES 
		( '${data.coupon_code}', ${data.seller_id},  '${data.valid_start}',  '${data.valid_end}', '${data.coupon_status}',  ${data.coupon_discount});`;
    }else{
		coupon_id = data.coupon_id;
		var sqlquery = `update product_coupon set coupon_code= '${data.coupon_code}',seller_id= ${data.seller_id}, valid_start = '${data.valid_start}',valid_end=  '${data.valid_end}', coupon_status ='${data.coupon_status}',  coupon_discount ='${data.coupon_discount}' WHERE coupon_id = ${data.coupon_id};`;
    }       
	configure.comman_sql_query(sqlquery,function(err,rows){
		if(err) {
			res.send({ "status":201, "err":err, "message":"Something went wrong" });
		} else {
			console.log("==============");
			console.log(coupon_id);
			if (coupon_id == 0) {
				coupon_id = rows.insertId;
			}
			console.log(coupon_id);
			sqlquery21 = "DELETE FROM `product_coupon_selected` WHERE `coupon_id` = " + coupon_id + ";";
			console.log(sqlquery21);
			configure.comman_sql_query(sqlquery21, function(err, rows1) {
			
				if (err) {
					res.send({"status": 201, "err": err,"message": "Something went wrong, Please try again."});
				} else {
							
					var selected_products = data.selected_products;
					var p_faq_counter = 0;
					for (t_c in selected_products) {
						console.log(p_faq_counter);
						sqlquery1 = "INSERT INTO `product_coupon_selected` ( `coupon_id`, `product_id`, `product_name`, `seller_id`, `coupon_code`) VALUES ( " + coupon_id + ", " + selected_products[t_c]['product_id'] + ", '" + selected_products[t_c]['product_name'] + "'," + data.seller_id + ",'" + data.coupon_code + "');";
						configure.comman_sql_query(sqlquery1, function(err, rows) {
							if (err) {
									res.send({"status": 201,"err": err,"message": "Something went wrong, Please try again."
									});
							} else {console.log('else');
								if(p_faq_counter == t_c){console.log('match');
									res.send({"status": 200,"data": rows,"message": "add Successfully"});
								}
							}
							p_faq_counter++;
						});
						 
					}
							
				}
			});
		}
                
      });
});

/* router.put('/update_coupon/:id',function(req,res,next){
	const data = req.body
	var sqlquery = `update product_coupon set coupon_code= '${data.coupon_code}',seller_id= ${data.seller_id}, valid_start = '${data.valid_start}',valid_start=  '${data.valid_start}', coupon_status ='${data.coupon_status}',  coupon_discount ='${data.coupon_discount}' WHERE coupon_id = ${req.params.id};`;
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
			console.log(err);
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Coupon updated successfully" });
        }
    });
}); */

router.post('/insert_impact',function(req,res,next){
var product_id = req.body.product_id;
var sqlquery = "DELETE FROM `product_impacts_selected` WHERE `product_id` = "+product_id+";";
	 configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
			var product_id = req.body.product_id;
			var selected_impact = req.body.selected_impact;
			var p_tag_counter = 0;
			for (t_c  in selected_impact) {
           sqlquery1 = "INSERT INTO `product_impacts_selected` ( `product_id`, `impacts_id`, `impact_name`) VALUES ( "+ product_id+", "+ selected_impact[t_c]['impacts_id']+", '"+ selected_impact[t_c]['impact_name']+"');";
			configure.comman_sql_query(sqlquery1,function(err,rows){
			if(err) {
			res.send({ "status":201, "err":err, "message":"Something went wrong, Please try again." });
			} else{
            if(p_tag_counter == t_c){
																							
				if(product_id == 0){
					res.send({ "status":200, "data":rows, "message":"Product Added Successfully" });
					}else{console.log('8');
					res.send({ "status":200, "data":rows,  "message":"Product Updated Successfully" });
					}
				}			
			}
			p_tag_counter++;
			});
        }
		
       }
    });
}); 

router.post('/insert_values',function(req,res,next){
var product_id = req.body.product_id;
var sqlquery = "DELETE FROM `product_values_selected` WHERE `product_id` = "+product_id+";";
	 configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
			var product_id = req.body.product_id;
			var selected_values = req.body.selected_values;
			var p_tag_counter = 0;
			for (t_c  in selected_values) {
           sqlquery1 = "INSERT INTO `product_values_selected` ( `product_id`, `values_id`, `value_name`) VALUES ( "+ product_id+", "+ selected_values[t_c]['values_id']+", '"+ selected_values[t_c]['value_name']+"');";
			configure.comman_sql_query(sqlquery1,function(err,rows){
			if(err) {
			res.send({ "status":201, "err":err, "message":"Something went wrong, Please try again." });
			} else{	
			 if(p_tag_counter == t_c){
																							
				if(product_id == 0){
					res.send({ "status":200, "data":rows, "message":"Product Added Successfully" });
					}else{console.log('8');
					res.send({ "status":200, "data":rows,  "message":"Product Updated Successfully" });
					}
				}
		}
			p_tag_counter++;
			});
			
        }
       }
    });
}); 

router.post('/add_product_seller',function(req,res,next){
	
	var product_id = req.body.product_id;
	var sqlquery = "";
	if(product_id == 0){
		sqlquery = "INSERT INTO `products` ( `menu_category_id`, `menu_category_name`, `menu_subcategory_id`, `menu_subcategory_name`, `product_category_id`, `product_category_name`, `product_subcategory_id`, `product_subcategory_name`, `product_brand_id`, `product_brand_name`, `product_name`, `product_desc`, `product_images`, `actual_price`, `discount_per`, `after_discount_price`, `valuess`,  `created_date`, `created_time`, `product_status`, `seller_id`, `seller_name`, `first_image_url`, `shipping_charge`, `impact_nature1`, `impact_nature2`, `impact_nature3`, `impact_nature4`, `img_impact_nature1`, `img_impact_nature2`, `img_impact_nature3`, `img_impact_nature4`, `inventory_value`, `inventory_yes_no`) VALUES ( "+req.body.menu_category_id+",'"+req.body.menu_category_name+"', "+ req.body.menu_subcategory_id+", '"+ req.body.menu_subcategory_name+"', "+ req.body.product_category_id+", '"+ req.body.product_category_name+"', "+ req.body.product_subcategory_id+", '"+ req.body.product_subcategory_name+"', "+ req.body.product_brand_id+", '"+ req.body.product_brand_name+"', '"+ req.body.product_name+"', '"+ req.body.product_desc+"', '"+ req.body.product_image+"', "+ req.body.actual_price+", "+ req.body.discount_per+", "+ req.body.after_discount_price+", '"+ req.body.valuess+"', '"+ req.body.created_date+"', '"+ req.body.created_time+"', 'active',"+ req.body.seller_id+",'"+ req.body.seller_name+"','"+ req.body.first_image_url+"','"+ req.body.shipping_charge+"','"+ req.body.impact_nature1+"','"+ req.body.impact_nature2+"','"+ req.body.impact_nature3+"','"+ req.body.impact_nature4+"','"+ req.body.img_impact_nature1+"','"+ req.body.img_impact_nature2+"','"+ req.body.img_impact_nature3+"','"+ req.body.img_impact_nature4+"','"+ req.body.inventory_value+"','"+ req.body.inventory_yes_no+"');";
	}else{
		sqlquery = "UPDATE `products` SET `menu_category_id` = "+req.body.menu_category_id+", `menu_category_name` = '"+req.body.menu_category_name+"',`menu_subcategory_id` = "+req.body.menu_subcategory_id+",`menu_subcategory_name` = '"+req.body.menu_subcategory_name+"',`product_category_id` = "+req.body.product_category_id+",`product_category_name` = '"+req.body.product_category_name+"',`product_subcategory_id` = "+req.body.product_subcategory_id+",`product_subcategory_name` = '"+req.body.product_subcategory_name+"',`product_brand_id` = "+req.body.product_brand_id+", `product_brand_name` = '"+req.body.product_brand_name+"', `product_name` = '"+req.body.product_name+"', `product_desc` = '"+req.body.product_desc+"', `product_images` = '"+req.body.product_image+"', `actual_price` = "+req.body.actual_price+", `discount_per` = "+req.body.discount_per+", `after_discount_price` = "+req.body.after_discount_price+", `valuess` = '"+req.body.valuess+"',  `seller_name` = '"+req.body.seller_name+"', `first_image_url` = '"+req.body.first_image_url+"', `shipping_charge` = '"+req.body.shipping_charge+"', `impact_nature1` = '"+req.body.impact_nature1+"', `impact_nature2` = '"+req.body.impact_nature2+"', `impact_nature3` = '"+req.body.impact_nature3+"', `impact_nature4` = '"+req.body.impact_nature4+"' , `img_impact_nature1` = '"+req.body.img_impact_nature1+"', `img_impact_nature2` = '"+req.body.img_impact_nature2+"', `img_impact_nature3` = '"+req.body.img_impact_nature3+"', `img_impact_nature4` = '"+req.body.img_impact_nature4+"', `inventory_value` = '"+req.body.inventory_value+"',  `inventory_yes_no` = '"+req.body.inventory_yes_no+"' WHERE `products`.`product_id` = "+product_id+";";
	}
    configure.comman_sql_query(sqlquery,function(err,rows){
		console.log(rows);
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong, Please try again." });
        } else{
			if(product_id == 0){
				product_id = rows.insertId;
			}
			/*delete all qunity first*/
			sqlquery2 = "DELETE FROM `product_quantity` WHERE `product_id` = "+product_id+";";
			console.log('2');
			configure.comman_sql_query(sqlquery2,function(err,rows){
				if(err) {
					res.send({ "status":201, "err":err, "message":"Something went wrong, Please try again." });
				} else{
					console.log('3');
					var sqlquery1 = "";
					var p_q = req.body.product_quantity;
					var p_q_counter = 0;
					for (pq_c  in p_q) {
						sqlquery1 = "INSERT INTO `product_quantity` ( `product_id`, `product_color_id`, `product_color_name`, `product_size_id`, `product_size_name`, `product_quantity`, `created_date`) VALUES ( "+ product_id+", "+ p_q[pq_c]['product_color_id']+", '"+ p_q[pq_c]['product_color_name']+"', "+ p_q[pq_c]['product_size_id']+", '"+ p_q[pq_c]['product_size_name']+"',"+ p_q[pq_c]['product_quantity']+", '"+ req.body.created_date+"');";
						console.log('4');
						configure.comman_sql_query(sqlquery1,function(err,rows){
							if(err) {
								res.send({ "status":201, "err":err, "message":"Something went wrong, Please try again." });
							} else{
								if(p_q_counter == pq_c){
									sqlquery21 = "DELETE FROM `product_tag_selected` WHERE `product_id` = "+product_id+";";
									configure.comman_sql_query(sqlquery21,function(err,rows){
										if(err) {
											res.send({ "status":201, "err":err, "message":"Something went wrong, Please try again." });
										} else{
											var selected_tags = req.body.selected_tags;
											var p_tag_counter = 0;
											for (t_c  in selected_tags) {
												sqlquery1 = "INSERT INTO `product_tag_selected` ( `product_id`, `tag_id`, `tag_name`) VALUES ( "+ product_id+", "+ selected_tags[t_c]['tag_id']+", '"+ selected_tags[t_c]['tag_name']+"');";
												
												configure.comman_sql_query(sqlquery1,function(err,rows){
													if(err) {
														res.send({ "status":201, "err":err, "message":"Something went wrong, Please try again." });
													} else{
														/*delete all faq first*/
														sqlquery21 = "DELETE FROM `product_faqs` WHERE `product_id` = "+product_id+";";
														configure.comman_sql_query(sqlquery21,function(err,rows){
															if(err) {
																res.send({ "status":201, "err":err, "message":"Something went wrong, Please try again." });
															} else{
																
																if(p_tag_counter == t_c){
																	var p_faq = req.body.product_faqs;
																	if(p_faq.length >0){
																		var p_faq_counter = 0;
																		for (pfaq_c  in p_faq) {
																			console.log('6');
																			sqlquery11 = "INSERT INTO `product_faqs` ( `product_id`, `product_faq_question`, `product_faq_answer`,  `seller_id`) VALUES ( "+ product_id+", '"+ p_faq[pfaq_c]['product_faq_question']+"', '"+ p_faq[pfaq_c]['product_faq_answer']+"',  "+ req.body.seller_id+");";
																			configure.comman_sql_query(sqlquery11,function(err,rows){
																				if(err) {
																					res.send({ "status":201, "err":err, "message":"Something went wrong, Please try again." });
																				} else{console.log('7');
																					if(p_faq_counter == pfaq_c){
																						/*all done */
																						if(product_id == 0){
																							res.send({ "status":200, "data":rows,"data1":product_id,  "message":"Product Added Successfully" });
																						}else{console.log('8');
																							res.send({ "status":200, "data":rows,"data1":product_id ,  "message":"Product Updated Successfully" });
																						}
																					}
																				}
																				p_faq_counter++;
																			});
																		}
																	}else{
																		if(product_id == 0){
																			res.send({ "status":200, "data":rows,"data1":product_id , "message":"Product Added Successfully" });
																		}else{console.log('8');
																			res.send({ "status":200, "data":rows, "data1":product_id , "message":"Product Updated Successfully" });
																		}
																	}
																}
															}
															p_tag_counter++;
														});
													}
												});
											}
											
										}
									});
									
									console.log('5');
									
									
									
								}
							}
							p_q_counter++;
						});
					}     
				}
			}); 
		}
	});
});		

router.post('/upload_seller_image',function(req,res,next){
	console.log('0');
		var randNo = Math.floor(Math.random() * 100) + 2 + "" + new Date().getTime() +  Math.floor(Math.random() * 100) + 2 + (Math.random().toString(36).replace(/[^a-zA-Z]+/g, '').substr(0, 5));
		const imgname = new Date().getTime().toString()+ "_"+randNo+".png";
		const imgdata = req.body.image_base_64;
		console.log('1');
		const base64Data = imgdata.replace(/^data:([A-Za-z-+/]+);base64,/, '');
		require("fs").writeFile("public/"+imgname, base64Data, 'base64', function(err) {
		  console.log(err);console.log('2');
		  res.send({ "status":200,  "imgname":imgname, "message":"Data get Successfully" });
		});
		console.log('done')
		
	/*configure.upload_image(req,function(err,rows){
		console.log('5');
		console.log(err);
		console.log(rows);
        if(err) {
            res.send({ "status":201, "err":err, "message":"Data not found" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Data get Successfully" });
        }
    });*/
	//res.send({ "status":200, "message":"Data get Successfully" });
});

router.post('/upload_seller_banner',function(req,res,next){
	console.log('0');
		var randNo = Math.floor(Math.random() * 100) + 2 + "" + new Date().getTime() +  Math.floor(Math.random() * 100) + 2 + (Math.random().toString(36).replace(/[^a-zA-Z]+/g, '').substr(0, 5));
		const imgname = new Date().getTime().toString()+ "_"+randNo+".png";
		const imgdata = req.body.image_base_64;
		console.log('1');
		const base64Data = imgdata.replace(/^data:([A-Za-z-+/]+);base64,/, '');
		require("fs").writeFile("public/"+imgname, base64Data, 'base64', function(err) {
		  console.log(err);console.log('2');
		  res.send({ "status":200,  "imgname":imgname, "message":"Data get Successfully" });
		});
		console.log('done')
		
	/*configure.upload_image(req,function(err,rows){
		console.log('5');
		console.log(err);
		console.log(rows);
        if(err) {
            res.send({ "status":201, "err":err, "message":"Data not found" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Data get Successfully" });
        }
    });*/
	//res.send({ "status":200, "message":"Data get Successfully" });
});

router.post('/get_all_sellerprofile_list',function(req,res,next){
	
	var sqlquery = "select * from seller_user WHERE seller_id = "+req.body.seller_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });

        }
    });
});

router.post('/get_all_customerprofile_list',function(req,res,next){
	
	var sqlquery = "select * from customer_user WHERE customer_id = "+req.body.customer_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/update_sellerprofile',function(req,res,next){
	var sqlquery = "";
	if(req.body.seller_id== 0){
		sqlquery = "INSERT INTO `seller_user` (`seller_name`, `	seller_email`, `seller_company`, `company_desc`, `seller_banner`, `seller_image`) VALUES ('"+req.body.seller_name+"', '"+req.body.seller_email+"', '"+req.body.seller_company+"', '"+req.body.company_desc+"', '"+req.body.seller_banner+"', '"+req.body.seller_image+"')";
	}else{
		sqlquery = "update seller_user set 	seller_name = '"+req.body.seller_name+"', seller_email = '"+req.body.seller_email+"', seller_company = '"+req.body.seller_company+"' , company_desc = '"+req.body.company_desc+"', seller_banner = '"+req.body.seller_banner+"', seller_image = '"+req.body.seller_image+"'  where seller_id= "+req.body.seller_id;
	}
	 
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":" profile has  Successfully updated" });
        }
    });
});
router.post('/update_customerprofile',function(req,res,next){
	var sqlquery = "";
	if(req.body.customer_id== 0){
		sqlquery = "INSERT INTO `customer_user` (`full_name`, `	customer_email`, `seller_company`, `customer_image`, `lname`, `company_name`, `country_name`, `city_name`, `zip_code`, `shipping_address`, `phone_number`) VALUES ('"+req.body.full_name+"', '"+req.body.customer_email+"', '"+req.body.customer_image+"', '"+req.body.lname+"', '"+req.body.company_name+"', '"+req.body.country_name+"', '"+req.body.city_name+"', '"+req.body.zip_code+"', '"+req.body.shipping_address+"', '"+req.body.phone_number+"')";
	}else{
		sqlquery = "update customer_user set 	full_name = '"+req.body.full_name+"', customer_email = '"+req.body.customer_email+"', customer_image = '"+req.body.customer_image+"', lname = '"+req.body.lname+"', company_name = '"+req.body.company_name+"', country_name = '"+req.body.country_name+"', city_name = '"+req.body.city_name+"', state_name = '"+req.body.state_name+"', zip_code = '"+req.body.zip_code+"', shipping_address = '"+req.body.shipping_address+"', phone_number = '"+req.body.phone_number+"'  where customer_id= "+req.body.customer_id;
	}
	 console.log(sqlquery);
    configure.comman_sql_query(sqlquery,function(err,rows){
		
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":" profile has  Successfully updated" });
        }
    });
});




router.delete('/remove_coupon/:id',function(req,res,next){
	
	var sqlquery = "update product_coupon set coupon_status = 'remove' WHERE `coupon_id` = "+req.params.id+"";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
			console.log(err);
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Deleted Successfully" });
        }
    });
});
router.post('/get_all_userprofile',function(req,res,next){
	
	var sqlquery = "select * from customer_user WHERE customer_id = "+req.body.customer_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/add_user', function(req, res, next) {
    var customer_id = req.body.customer_id;
    
        var sqlquery = "select * from customer_user where customer_email = '" + req.body.customer_email + "'";
	
        configure.comman_sql_query(sqlquery, function(err, row) {
			 var result = JSON.parse(JSON.stringify(row));
                if (_.size(result) > 0 && _.size(result) === 1) {
                    res.send({"status": 201,"message": "Email id already exist." });
                } else {
					var customer_verification_code = "ss";
				     var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
				     for (var i = 0; i < 25; i++){
					customer_verification_code += possible.charAt(Math.floor(Math.random() * possible.length));
				     }
					var customer_password = bcrypt.hashSync(req.body.customer_pass, 10);
				    var sqlquery = "INSERT INTO `customer_user` (`full_name`, `lname`, `customer_email`, `customer_pass`, `created_date`, `created_time`, `customer_verification_code`, `company_name`, `country_name`, `city_name`, `state_name`, `zip_code`, `shipping_address`, `phone_number` , `shipping_first_name`, `shipping_last_name`, `shipping_company_name`, `shipping_address_name`, `shipping_city`, `shipping_country`, `shipping_state`, `shipping_pin_code`, `shipping_phone_number`) VALUES ('" + req.body.full_name + "', '" + req.body.lname + "', '" + req.body.customer_email + "', '" + customer_password + "', '" + req.body.created_date + "', '" + req.body.created_time + "', '" + customer_verification_code + "', '" + req.body.company_name + "', '" + req.body.country_name + "', '" + req.body.city_name + "', '" + req.body.state_name + "', '" + req.body.zip_code + "', '" + req.body.shipping_address + "', '" + req.body.phone_number + "', '" + req.body.shipping_first_name + "', '" + req.body.shipping_last_name + "', '" + req.body.shipping_company_name + "', '" + req.body.shipping_address_name + "', '" + req.body.shipping_city + "', '" + req.body.shipping_country + "', '" + req.body.shipping_state + "', '" + req.body.shipping_pin_code + "', '" + req.body.shipping_phone_number + "')";
                   
                    configure.comman_sql_query(sqlquery, function(err, row) {
						console.log(row);
                        if (err) {
                            res.send({ "status": 201,"err": err, "message": "Something wend wrong. Please try again"});
                        } else {
                            var full_name = (req.body.full_name);
                            req.body.customer_email = req.body.customer_email;
                            req.body.subject = 'Veggmi verificateion email';
                           req.body.html = '<div><div style="background-color: #eee;padding: 20px;font-size: 20px;"><div style="text-align: center; border-bottom: 1px solid;"><a href="http://veggmi.com/">VEGGMI</a></div><br/><br/>Dear '+full_name+'<br/><br/><p>Please Click the bellow to verify your email address</p><a href="http://veggmi.xyz/customer-verify/'+customer_verification_code+'">Click Here</a><br/><br/><div style="border-top: 1px solid;"><span style="font-size: 10px;">Copyright &copy; . All Rights Reserved.</span></div><br/></div></div>';
						   // configure.sendemail(req, function(err, row) {});
						   console.log(req.body.html);
                            res.send({"status": 200,"data": row,"message": "Your account has been created successfully. Please login to continue."});
                        }
                    });
                }
            
        });

});
router.post('/update_user',function(req,res,next){
	
	sqlquery = "update customer_user set 	full_name = '"+req.body.full_name+"', lname = '"+req.body.lname+"', customer_email = '"+req.body.customer_email+"' , company_name = '"+req.body.company_name+"', country_name = '"+req.body.country_name+"', city_name = '"+req.body.city_name+"', 	state_name = '"+req.body.state_name+"', zip_code = '"+req.body.zip_code+"', shipping_address = '"+req.body.shipping_address+"', phone_number = '"+req.body.phone_number+"', shipping_first_name = '"+req.body.shipping_first_name+"', shipping_last_name = '"+req.body.shipping_last_name+"', shipping_company_name = '"+req.body.shipping_company_name+"', shipping_address_name = '"+req.body.shipping_address_name+"', 	shipping_city = '"+req.body.shipping_city+"', shipping_state = '"+req.body.shipping_state+"', shipping_pin_code = '"+req.body.shipping_pin_code+"', shipping_phone_number = '"+req.body.shipping_phone_number+"' where customer_id= "+req.body.customer_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"profile has  Successfully updated" });
        }
    });
});
router.post('/best_selling_product',function(req,res,next){
	sqlquery = "SELECT products.*,COUNT(*)as products_count FROM product_order_details INNER JOIN products ON product_order_details.product_id=products.product_id where products.product_status != 'remove'  AND product_order_details.seller_id='"+req.body.seller_id+"' GROUP BY product_id ORDER BY COUNT(*) DESC LIMIT 10";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"profile has  Successfully updated" });
        }
    });
});

router.post('/most_visited_product',function(req,res,next){
	sqlquery = "SELECT products.*,COUNT(*)as products_count FROM recent_visited_product INNER JOIN products ON recent_visited_product.product_id=products.product_id where products.seller_id='"+req.body.seller_id+"' AND products.product_status != 'remove' GROUP BY product_id ORDER BY COUNT(*) DESC LIMIT 10";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"profile has  Successfully updated" });
        }
    });
});

router.post('/inventory_remaining_product',function(req,res,next){
	sqlquery = "SELECT  products.product_id,products.product_name,products.product_category_name,products.product_status,SUM(product_quantity.product_quantity) AS product_quantity,products.inventory_value,  SUM(product_quantity.product_quantity)- products.inventory_value  AS remainingquatity FROM `products` left outer JOIN product_quantity ON (products.product_id =product_quantity.product_id)  WHERE products.seller_id= '"+req.body.seller_id+"' AND products.product_status != 'remove' AND products.inventory_yes_no = 'yes' group by products.product_id";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"profile has  Successfully updated" });
        }
    });
});
router.post('/get_all_best_selling_product_list',function(req,res,next){
	
	sqlquery = "SELECT products.*,COUNT(*)as products_count,SUM(product_order_details.total_paid_amount)AS revenue FROM product_order_details INNER JOIN products ON product_order_details.product_id=products.product_id where products.product_status != 'remove' AND product_order_details.created_date >= '"+req.body.from+"' and product_order_details.created_date <= '"+req.body.to+"'  AND  product_order_details.seller_id='"+req.body.seller_id+"' GROUP BY product_id ORDER BY COUNT(*) DESC ";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/most_view_product_list',function(req,res,next){
	sqlquery = "SELECT products.*,COUNT(*)as products_count FROM recent_visited_product INNER JOIN products ON recent_visited_product.product_id=products.product_id where products.seller_id='"+req.body.seller_id+"' AND recent_visited_product.created_date >= '"+req.body.from+"' and recent_visited_product.created_date <= '"+req.body.to+"' AND products.product_status != 'remove' GROUP BY product_id ORDER BY COUNT(*) DESC ";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows,"sqlquery":sqlquery, "message":"profile has  Successfully updated" });
        }
    });
});
router.post('/selling_location_product_list',function(req,res,next){
	sqlquery = "SELECT *, SUM(product_order_details.product_quantity) as total_orders FROM `product_order_details` left OUTER JOIN customer_user ON (product_order_details.customer_id =customer_user.customer_id) left OUTER JOIN products ON (products.product_id = product_order_details.product_id) WHERE product_order_details.seller_id= '"+req.body.seller_id+"' AND product_order_details.created_date >= '"+req.body.from+"' and product_order_details.created_date <= '"+req.body.to+"'  AND products.product_status != 'remove' group by customer_user.city_name";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"profile has  Successfully updated" });
        }
    });
});
router.post('/product_inventory',function(req,res,next){
	sqlquery = "SELECT *, products.product_id, SUM(product_quantity.product_quantity) AS product_quantity_remaining FROM `products` left outer JOIN product_quantity ON (products.product_id =product_quantity.product_id) LEFT JOIN ( SELECT product_id, SUM(product_quantity) AS till_order_count FROM product_order_details GROUP BY 1 ) p ON p.product_id = products.product_id WHERE products.seller_id= '"+req.body.seller_id+"' AND products.created_date >= '"+req.body.from+"' and products.created_date <= '"+req.body.to+"'  AND products.product_status != 'remove' group by product_quantity.product_id";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"profile has  Successfully updated" });
        }
    });
});

module.exports=router;