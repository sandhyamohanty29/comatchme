var express = require('express');
var router = express.Router();
var configure=require('../models/configure');
var Filter=require('../models/filter');
var Transition=require('../models/transition');
var _ = require('lodash');

router.get('/getProductTypeFilter',function(req,res,next){
    Filter.getProductTypeFilter(function(err,rows){
        if(err){ res.json(err); }
        else{ res.json(rows); }
    });
});

router.post('/getFilterProduct',function(req,res,next){
    Filter.getFilterProductList(req.body, function(err,rows){
        if(err){ res.json(err); }
        else{   
			if(rows.totalPages > 0){
				
				let list1 = []; 
				rows.productList.map(async function (data, index) {
					
					var sqlquery = "SELECT * from favourite_product where product_id="+data.product_id+" and customer_id="+req.body.customer_id;
					let data1 = await getProductFavirate(sqlquery,rows.productList[index],req.body.customer_id)
 
					if(data1){	
						console.log('data1',data1)
						list1.push(data1);				
						if(rows.productList.length == index+1){
							res.json(rows); 
						}
					}
				});
			}else{
				res.json(rows);				
			}
		}
    }); 
});

async function getProductFavirate(sqlquery,iterator,cusId){
	let result = await new Promise((resolve, rej) => {
		Transition.getProductFavirate(iterator.product_id, cusId, function (err, sub) {
			var result = JSON.parse(JSON.stringify(sub));
			console.log('iterator');
			console.log(iterator);
			console.log(_.size(result));
			iterator['getProductFavirate'] = _.size(result);
			var product_name_url = (iterator['product_name']).toLowerCase().replace(/[^a-zA-Z0-9]/g, '-');
			iterator['product_name_url'] = product_name_url;
			var product_name_lenght = product_name_url.length;
			if (product_name_lenght > 18) {
				var product_name_trim = iterator['product_name'].substring(0, 15);
				iterator['product_name_trim'] = product_name_trim + '...';
			} else {
				iterator['product_name_trim'] = iterator['product_name'];
			}
			iterator['product_rating'] = iterator['product_rating'];
			console.log(iterator);
			resolve(iterator);
		});
	})
return result;
}
module.exports=router;