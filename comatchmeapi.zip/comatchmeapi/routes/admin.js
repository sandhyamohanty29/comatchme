var express = require('express');
var router = express.Router();
var bcrypt = require('bcryptjs');
var Category=require('../models/category');
var _ = require('lodash');
var configure=require('../models/configure');

router.post('/check_admin_auth',function(req,res,next){
	
	//var admin_password = bcrypt.hashSync(req.body.admin_password, 10);
	//var admin_password = bcrypt.compareSync(password, result[0].req.body.admin_password);
	var sqlquery = "select * from veggmi_admin where admin_email = '"+req.body.admin_email+"'";
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Invalid login details" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
                if(bcrypt.compareSync(req.body.admin_password, result[0].admin_password)){
					res.send({ "status":200, "data":result, "message":"Successfully Login" });
                  
                } else{
					res.send({ "status":201, "data":result, "message":"Invalid Password" });
                }
            } else{
                res.send({ "status":201, "data":result, "message":"Invalid Email" });
            }
        }
    });
	
});

router.post('/admin_forgetpassword',function(req,res,next){
	
	var sqlquery = "select * from veggmi_admin where admin_email = '"+req.body.admin_email+"'";
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Invalid email" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				/*Insert new verification_code*/
				var verification_code = 'ss';
				var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
				for (var i = 0; i < 25; i++){
					verification_code += possible.charAt(Math.floor(Math.random() * possible.length));
				}
				var insert_veroif_query = "UPDATE `veggmi_admin` SET `verification_code` = '"+verification_code+"' WHERE `veggmi_admin_id` = "+result[0].veggmi_admin_id;
				configure.comman_sql_query(insert_veroif_query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						 /*send forget password email*/
						var full_name= (result[0].full_name);
						req.body.email = result[0].admin_email;
						req.body.subject = 'Veggmi Password Reset';
						req.body.html = '<div><div style="background-color: #eee;padding: 20px;font-size: 20px;"><div style="text-align: center; border-bottom: 1px solid;"><a href="https://veggmi.com/">VEGGMI</a></div><br/><br/>Dear '+full_name+'<br/><br/><p>Please Click the bellow to change your password</p><a href="https://admin.veggmi.xyz/admin-resetpassword/'+verification_code+'">Click Here</a><br/><br/><div style="border-top: 1px solid;"><span style="font-size: 10px;">Copyright &copy; . All Rights Reserved.</span></div><br/></div></div>';
						configure.sendemail(req,function(err,rows){});
						res.send({ "status":200, "data":rows, "err":err, "message":"Rest password email sent Successfully" });
					}
				});
               
            } else{
                res.send({ "status":201, "data":result, "message":"Invalid Email" });
            }
        }
    });
	
});

router.post('/admin_resetpassword',function(req,res,next){
	
	var sqlquery = "select * from veggmi_admin where verification_code = '"+req.body.verification_code+"'";
	
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Verification code either expire or wrong" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
				/*Insert new password*/
				
				var admin_password = bcrypt.hashSync(req.body.new_password, 10);
				
				var insert_veroif_query = "UPDATE `veggmi_admin` SET `admin_password` = '"+admin_password+"' WHERE `veggmi_admin_id` = "+result[0].veggmi_admin_id;
				configure.comman_sql_query(insert_veroif_query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						res.send({ "status":200, "data":rows, "message":"Password update Successfully" });
					}
				});
               
            } else{
				res.send({ "status":201, "message":"Verification code either expire or wrong" });
            }
        }
    });
	
});

router.post('/sendemail',function(req,res,next){
	configure.sendemail(req,function(err,rows){});
	res.send({ "status":200, "data":rows, "err":err, "message":"Rest password email sent Successfully" });
					
}); 
router.post('/check_admin_changepass_auth',function(req,res,next){
	var sqlquery = "SELECT * FROM `veggmi_admin` WHERE `veggmi_admin_id` = "+req.body.veggmi_admin_id;
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":" something wrong " });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			console.log(rows);
			console.log(_.size(result));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
                if(bcrypt.compareSync(req.body.current_password, result[0].	admin_password)){
				var admin_password = bcrypt.hashSync(req.body.new_password, 10);
                var query = "UPDATE `veggmi_admin` SET `admin_password` = '"+admin_password+"' WHERE `veggmi_admin`.`veggmi_admin_id` = "+req.body.veggmi_admin_id;
				configure.comman_sql_query(query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						
						res.send({ "status":200, "data":rows, "message":"Password updated Successfully" });
					}
				});
				  
                } else{
					res.send({ "status":201, "data":result, "message":"Invalid old Password" });
                }
            } else{
                res.send({ "status":201, "data":result, "message":"Something went wrong, try again." });
            }
        }
    });
	
});
router.post('/get_all_adminprofile_list',function(req,res,next){
	
	var sqlquery = "select * from veggmi_admin WHERE veggmi_admin_id = "+req.body.veggmi_admin_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/insert_profile',function(req,res,next){
	var sqlquery = "";
	if(req.body.veggmi_admin_id== 0){
		sqlquery = "INSERT INTO `veggmi_admin` (`full_name`, `admin_email`, `contact`) VALUES ('"+req.body.full_name+"', '"+req.body.admin_email+"', '"+req.body.contact+"')";
	}else{
		sqlquery = "update veggmi_admin set full_name = '"+req.body.full_name+"', admin_email = '"+req.body.admin_email+"', contact = '"+req.body.contact+"' , admin_img = '"+req.body.admin_img+"'  where veggmi_admin_id= "+req.body.veggmi_admin_id;
	}
	 
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Successfully submitted" });
        }
    });
});

router.post('/get_products_count',function(req,res,next){
	var sqlquery = "SELECT count(*) as products_count FROM `products`";
    configure.comman_sql_query(sqlquery,function(err,products_count){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "products_count":products_count, "message":"Successfully submitted" });
        }
    });
});

router.post('/get_recent_products',function(req,res,next){
	
	var sqlquery = "select * from products ORDER BY created_date DESC  LIMIT 4";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/get_recent_seller_list',function(req,res,next){
	
	var sqlquery = "select * from seller_user ORDER BY created_date DESC  LIMIT 4";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/get_recent_customer_list',function(req,res,next){
	
	var sqlquery = "select * from customer_user ORDER BY created_date DESC  LIMIT 4";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/get_recent_order_list',function(req,res,next){
	
	var sqlquery = "select * from product_order_details ORDER BY created_date DESC  LIMIT 4";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
		
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
			if(rows.length > 0){
				
				rows.map(function(data,index){
					Category.getProductName(data.product_id,function(err,sub){
						if(sub.length > 0){
							rows[index]['product_name']=sub[0].product_name ;
							rows[index]['product1']= 1;
						}else{
							rows[index]['product_name']= 'Removed';
							rows[index]['product1']= 0;
						}
						
						if(rows.length == index+1){
							rows.map(function(data,index){
								Category.getSellerName(data.seller_id,function(err,sub1){
									if(sub1.length > 0){
										rows[index]['seller_name']=sub1[0].seller_name ;
										rows[index]['seller_1']= 1;
									}else{
										rows[index]['seller_name']= 'Removed';
										rows[index]['seller_1']= 0;
									}
									if(rows.length == index+1){
										res.send({ "status":200, "data":rows, "message":"Fatched Successfully" }); 
									}
								});
							});
						}
					});
				});
			}else{
				res.send({ "status":200, "data":rows, "message":"Fatched Successfully" }); 
			}
		}
    });
});
router.post('/get_all_order_list',function(req,res,next){
	
	var sqlquery = "select * from product_order_details WHERE created_date >= '"+req.body.from+"' and created_date <= '"+req.body.to+"'";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
		
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
			if(rows.length > 0){
				
				rows.map(function(data,index){
					Category.getProductName(data.product_id,function(err,sub){
						if(sub.length > 0){
							rows[index]['product_name']=sub[0].product_name ;
							rows[index]['product1']= 1;
						}else{
							rows[index]['product_name']= 'Removed';
							rows[index]['product1']= 0;
						}
						
						if(rows.length == index+1){
							rows.map(function(data,index){
								Category.getSellerName(data.seller_id,function(err,sub1){
									if(sub1.length > 0){
										rows[index]['seller_name']=sub1[0].seller_name ;
										rows[index]['seller_1']= 1;
									}else{
										rows[index]['seller_name']= 'Removed';
										rows[index]['seller_1']= 0;
									}
									if(rows.length == index+1){
										res.send({ "status":200, "data":rows, "message":"Fatched Successfully" }); 
									}
								});
							});
						}
					});
				});
			}else{
				res.send({ "status":200, "data":rows, "message":"Fatched Successfully" }); 
			}
		}
    });
});
router.post('/get_product_order',function(req,res,next){
	var sqlquery = "SELECT * FROM `product_order` WHERE `product_order_id` = '"+req.body.product_order_id+"'";
	configure.comman_sql_query(sqlquery,function(err,row){
		if(err) {
			res.send({ "status":201, "err":err, "message":"Something went wrong" });
		} else{
			res.send({ "status":200, "data":row, "message":"Fatched Successfully" }); 
		}
	});
});
router.post('/get_order_detail',function(req,res,next){
	
	var sqlquery = "select * from product_order_details where product_order_id = "+req.body.product_order_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
		
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
			if(rows.length > 0){
				
				rows.map(function(data,index){
					Category.getProductName(data.product_id,function(err,sub){
						if(sub.length > 0){
							rows[index]['product_name']=sub[0].product_name ;
							rows[index]['product_category_name']=sub[0].product_category_name ;
							rows[index]['product_subcategory_name']=sub[0].product_subcategory_name ;
							rows[index]['menu_category_name']=sub[0].menu_category_name ;
							rows[index]['menu_subcategory_name']=sub[0].menu_subcategory_name ;
							rows[index]['product_brand_name']=sub[0].product_brand_name ;
							
							rows[index]['product_images']=sub[0].product_images ;
							
							rows[index]['product1']= 1;
						}else{
							rows[index]['product_name']= 'Removed';
							rows[index]['product1']= 0;
						}
						
						if(rows.length == index+1){
							rows.map(function(data,index){
								Category.getSellerName(data.seller_id,function(err,sub1){
									if(sub1.length > 0){
										rows[index]['seller_name']=sub1[0].seller_name ;
										rows[index]['seller_1']= 1;
									}else{
										rows[index]['seller_name']= 'Removed';
										rows[index]['seller_1']= 0;
									}
									if(rows.length == index+1){
										res.send({ "status":200, "data":rows, "message":"Fatched Successfully" }); 
									}
								});
							});
						}
					});
				});
			}else{
				res.send({ "status":200, "data":rows, "message":"Fatched Successfully" }); 
			}
		}
    });
});

router.post('/get_seller_count',function(req,res,next){
	var sqlquery = "SELECT count(*) as seller_count FROM `seller_user`";
    configure.comman_sql_query(sqlquery,function(err,seller_count){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "seller_count":seller_count, "message":"Successfully submitted" });
        }
    });
});
router.post('/get_sales_count',function(req,res,next){
	var sqlquery = "SELECT count(*) as sales_count FROM `product_order`";
    configure.comman_sql_query(sqlquery,function(err,sales_count){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "sales_count":sales_count, "message":"Successfully submitted" });
        }
    });
});
router.post('/get_customer_count',function(req,res,next){
	var sqlquery = "SELECT count(*) as customer_count FROM `customer_user`";
    configure.comman_sql_query(sqlquery,function(err,customer_count){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "customer_count":customer_count, "message":"Successfully submitted" });
        }
    });
});


module.exports=router;