var express = require('express');
var express = require('express');
var router = express.Router();
var configure=require('../models/configure');
var Transition=require('../models/transition');
var Category=require('../models/category');
var bcrypt = require('bcryptjs');
var _ = require('lodash');


router.post('/add_user',function(req,res,next){
	var user_id = req.body.user_id;
	var sqlquery = "INSERT INTO `user_registration` (`first_name`, `last_name`,`email_id`, `country_name`, `city_name`, `user_name`, `user_type`, `select_skill_cate_id`, `select_skill_cate_name`, `professional_skillets`, `describe_professional_skillets`, `profile_image`, `startup_phage`, `trying_solve`, `elevator_pitch`, `doing_startup`, `title_startup`, `description_startup`, `ideal_co_founder`) VALUES ('"+req.body.first_name+"', '"+req.body.last_name+"', '"+req.body.email_id+"', '"+req.body.country_name+"', '"+req.body.city_name+"', '"+req.body.select_user+"', '"+req.body.user_type+"', '"+req.body.select_skill_cate_id+"', '"+req.body.select_skill_cate_name+"', '"+req.body.professional_skillets+"', '"+req.body.describe_professional_skillets+"', '"+req.body.profile_image+"', '"+req.body.startup_phage+"', '"+req.body.trying_solve+"', '"+req.body.elevator_pitch+"', '"+req.body.doing_startup+"', '"+req.body.title_startup+"', '"+req.body.description_startup+"', '"+req.body.ideal_co_founder+"')";
    
	configure.comman_sql_query(sqlquery,function(err,row){
        if(err) {
            res.send({ "status":201, "message":"Data not found" });
          } else{
			 
			 if(user_id == 0){
				user_id = row.insertId;
				console.log('2');
			  }
			  var p_q = req.body.selected_skill;
			  var p_q_counter = 0;
			  for (pq_c  in p_q) {
				  sqlquery1 = "INSERT INTO `user_skills` ( `user_id`, `skill_id`, `skill_name`) VALUES ( "+ user_id+", "+ p_q[pq_c]['skill_id']+", '"+ p_q[pq_c]['skill_name']+"');";
				configure.comman_sql_query(sqlquery1,function(err,rows){
						if(err) {
							console.log('3');
							res.send({ "status":201, "message":"Data not found" });
						} else{
							console.log('4');
							if(p_q_counter == 1){
								res.send({ "status":200, "data":row,"data1":user_id , "message":" User Registration Successfully" });
							}
						}
						p_q_counter++;
					});
			}
        }
    });
	
});

router.post('/game_category',function(req,res,next){
	var sqlquery = "select * from category";
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Data not found" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Get category Successfully" });
        }
    });
	
});

router.post('/get_all_skill_list',function(req,res,next){
	var sqlquery = "select * from skills";
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Data not found 1" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Get skills Successfully 1" });
        }
    });
});
router.post('/get_all_slider_list',function(req,res,next){
	var sqlquery = "select * from home_slider";
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) { 
            res.send({ "status":201, "message":"Data not found" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Get slider Successfully" });
        }
    });
});

router.post('/get_all_user_details',function(req,res,next){
	
	var sqlquery = "select * from `user_registration` WHERE `user_id` = "+req.body.user_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/get_all_user_skills',function(req,res,next){
	
	var sqlquery = "select * from `user_skills` WHERE `user_id` = "+req.body.user_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/edit_skillets',function(req,res,next){
	
	var sqlquery = "update  user_registration set professional_skillets = '"+req.body.professional_skillets+"', describe_professional_skillets= '"+req.body.describe_professional_skillets+"' where user_id= "+req.body.user_id;
	
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Edit Successfully" });
        }
    });
});

module.exports=router;