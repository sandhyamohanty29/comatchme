var express = require('express');
var router = express.Router();
var configure=require('../models/configure');
var bcrypt = require('bcryptjs');
var _ = require('lodash');  

router.post('/upload_image',function(req,res,next){
	console.log('0');
		var randNo = Math.floor(Math.random() * 100) + 2 + "" + new Date().getTime() +  Math.floor(Math.random() * 100) + 2 + (Math.random().toString(36).replace(/[^a-zA-Z]+/g, '').substr(0, 5));
		const imgname = new Date().getTime().toString()+ "_"+randNo+".png";
		const imgdata = req.body.image_base_64;
		console.log('1');
		const base64Data = imgdata.replace(/^data:([A-Za-z-+/]+);base64,/, '');
		require("fs").writeFile("public/"+imgname, base64Data, 'base64', function(err) {
		  console.log(err);console.log('2');
		  res.send({ "status":200,  "imgname":imgname, "message":"Data get Successfully" });
		});
		console.log('done')
		
	/*configure.upload_image(req,function(err,rows){
		console.log('5');
		console.log(err);
		console.log(rows);
        if(err) {
            res.send({ "status":201, "err":err, "message":"Data not found" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Data get Successfully" });
        }
    });*/
	//res.send({ "status":200, "message":"Data get Successfully" });
});

router.post('/profile_upload_image',function(req,res,next){
	console.log('0');
		var randNo = Math.floor(Math.random() * 100) + 2 + "" + new Date().getTime() +  Math.floor(Math.random() * 100) + 2 + (Math.random().toString(36).replace(/[^a-zA-Z]+/g, '').substr(0, 5));
		const imgname = new Date().getTime().toString()+ "_"+randNo+".png";
		const imgdata = req.body.image_base_64;
		console.log('1');
		const base64Data = imgdata.replace(/^data:([A-Za-z-+/]+);base64,/, '');
		
		var sqlquery = "update  user_registration set profile_image = '"+imgname+"' where user_id= "+req.body.user_id;
	
	    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
              require("fs").writeFile("public/"+imgname, base64Data, 'base64', function(err) {
		      console.log(err);console.log('2');
		     res.send({ "status":200,  "imgname":imgname, "message":"Data get Successfully" });
		});       
	   }
    });
		
		console.log('done')
		
});

router.post('/testemail',function(req,res,next){
	configure.testemail(req,function(err,rows){});
	res.send({ "status":200, "message":"Data get Successfully" });
	
});

router.post('/public_conten_change_get_detail',function(req,res,next){
	var sqlquery = "select * from public_content where content_id= "+req.body.content_id;
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Data not found" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Data get Successfully" });
        }
    });
	
});

router.post('/update_content',function(req,res,next){
	var sqlquery = "update  public_content set content = '"+req.body.content+"', arabic_content= '"+req.body.arabic_content+"' where content_id= "+req.body.content_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Updated Successfully" });
        }
    });
	
});

router.post('/insert_category',function(req,res,next){
	var sqlquery = "";
	if(req.body.category_id==0){
		sqlquery = "INSERT INTO `category` (`category_name`,`arabic_category_name`) VALUES ('"+req.body.category_name+"','"+req.body.arabic_category_name+"')";
	}else{
		sqlquery = "update category set category_name= '"+req.body.category_name+"',arabic_category_name = '"+req.body.arabic_category_name+"' where category_id= "+req.body.category_id;
	}
	 
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Successfully submitted" });
        }
    });
});

router.post('/insert_cantent_management',function(req,res,next){
	var sqlquery = "";
	if(req.body.content_id==0){
		sqlquery = "INSERT INTO `content_management` (`main_key`,`english_text`,`arabic_text`,`page_name`) VALUES ('"+req.body.main_key+"','"+req.body.english_text+"','"+req.body.arabic_text+"','"+req.body.page_name+"')";
	}else{
		sqlquery = "update content_management set main_key= '"+req.body.main_key+"',english_text = '"+req.body.english_text+"',arabic_text = '"+req.body.arabic_text+"',page_name = '"+req.body.page_name+"' where content_id= "+req.body.content_id;
	}
	 
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Successfully submitted" });
        }
    });
});

router.post('/insert_skill',function(req,res,next){
	var sqlquery = "";
	if(req.body.skill_id == 0){
		sqlquery = "INSERT INTO `skills`(`category_id`,`skill_name`,`arabic_skill_name`)VALUES('"+req.body.category_id+"','"+req.body.skill_name+"','"+req.body.arabic_skill_name+"')";
	}else{
		sqlquery = "update skills set skill_name= '"+req.body.skill_name+"',category_id= '"+req.body.category_id+"',arabic_skill_name= '"+req.body.arabic_skill_name+"' where skill_id= "+req.body.skill_id;
	}
	 
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Successfully submitted" });
        }
    });
});


router.post('/get_all_category_list',function(req,res,next){
	
	var sqlquery = "SELECT * FROM category";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/get_all_skill_list',function(req,res,next){
	
	var sqlquery = "SELECT * FROM skills";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/removecategory',function(req,res,next){
	
	var sqlquery = "DELETE FROM `category` WHERE `category_id` = "+req.body.category_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Deleted Successfully" });
        }
    });
});
router.post('/remove_skill',function(req,res,next){
	
	var sqlquery = "DELETE FROM `skills` WHERE `skill_id` = "+req.body.skill_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Deleted Successfully" });
        }
    });
});

router.post('/get_enquiry_list',function(req,res,next){
	
	var sqlquery = "select * from enquiry";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/get_content_list',function(req,res,next){
	
	var sqlquery = "select * from content_management ";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/get_content_by_id',function(req,res,next){
	
	var sqlquery = "select * from content_management WHERE `content_id` = "+req.body.content_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/get_faq_list',function(req,res,next){
	
	var sqlquery = "SELECT * FROM `faq_question`";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/remove_content',function(req,res,next){
	
	var sqlquery = "DELETE FROM `content_management` WHERE `content_id` = "+req.body.content_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Deleted Successfully" });
        }
    });
});

router.post('/remove_enquiry',function(req,res,next){
	
	var sqlquery = "DELETE FROM `enquiry` WHERE `enquiry_id` = "+req.body.enquiry_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Deleted Successfully" });
        }
    });
});


router.post('/remove_faq',function(req,res,next){
	
	var sqlquery = "DELETE FROM `faq_question` WHERE `faq_question_id` = "+req.body.faq_question_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Deleted Successfully" });
        }
    });
});


router.post('/insert_faq',function(req,res,next){
	var sqlquery = "";
	if(req.body.faq_id== 0){
	sqlquery = "INSERT INTO `faq_question` (`faq_question`,`faq_content` ,`created_date`,`created_time`) VALUES ('"+req.body.faq_name+"','"+req.body.faq_content+"','"+req.body.created_date+"','"+req.body.created_time+"')";
	}else{
		sqlquery = "update `faq_question` set `faq_question` = '"+req.body.faq_name+"', `faq_content` = '"+req.body.faq_content+"', `created_date` = '"+req.body.created_date+"', `created_time` = '"+req.body.created_time+"' where `faq_question_id` = "+req.body.faq_id;
	}
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Successfully submitted" });
        }
    });
});

router.post('/get_faq_by_id',function(req,res,next){
	
	var sqlquery = "select * from `faq_question` WHERE `faq_question_id` = "+req.body.faq_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});


router.post('/get_public_contact_info',function(req,res,next){
	
	var sqlquery = "select * from contactus_content ";
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});
router.post('/update_public_contact_info',function(req,res,next){
	var sqlquery = "update contactus_content set contact_name = '"+req.body.contact_name+"', contact_email = '"+req.body.contact_email+"', contact_number = '"+req.body.contact_number+"', contact_url = '"+req.body.contact_url+"', contact_facebook = '"+req.body.contact_facebook+"', contact_twitter = '"+req.body.contact_twitter+"', contact_address = '"+req.body.contact_address+"', contact_youtube = '"+req.body.contact_youtube+"', contact_pinterest = '"+req.body.contact_pinterest+"', google_plus = '"+req.body.google_plus+"'  where contactus_content_id= "+req.body.contactus_content_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Updated Successfully" });
        }
    });
	
});

router.post('/check_admin_auth',function(req,res,next){
	
	var sqlquery = "select * from admin where admin_email = '"+req.body.admin_email+"'";
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Invalid login details" });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
                if(bcrypt.compareSync(req.body.admin_password, result[0].admin_password)){
					res.send({ "status":200, "data":result, "message":"Successfully Login" });
                  
                } else{
					res.send({ "status":201, "data":result, "message":"Invalid Password" });
                }
            } else{
                res.send({ "status":201, "data":result, "message":"Invalid Email" });
            }
        }
    });
	
});

router.post('/check_admin_changepass_auth',function(req,res,next){
	var sqlquery = "SELECT * FROM `admin` WHERE `admin_id` = "+req.body.admin_id;
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":" something wrong " });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			console.log(rows);
			console.log(_.size(result));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
                if(bcrypt.compareSync(req.body.current_password, result[0].	admin_password)){
				var admin_password = bcrypt.hashSync(req.body.new_password, 10);
                var query = "UPDATE `admin` SET `admin_password` = '"+admin_password+"' WHERE `admin`.`admin_id` = "+req.body.admin_id;
				configure.comman_sql_query(query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						
						res.send({ "status":200, "data":rows, "message":"Password updated Successfully" });
					}
				});
				  
                } else{
					res.send({ "status":201, "data":result, "message":"Invalid old Password" });
                }
            } else{
                res.send({ "status":201, "data":result, "message":"Something went wrong, try again." });
            }
        }
    });
	
});

router.post('/check_admin_changepass_auth',function(req,res,next){
	var sqlquery = "SELECT * FROM `admin` WHERE `admin_id` = "+req.body.admin_id;
	console.log(sqlquery);
	configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":" something wrong " });
        } else{
			var result = JSON.parse(JSON.stringify(rows));
			console.log(rows);
			console.log(_.size(result));
			if( _.size(result) > 0 &&  _.size(result) === 1) {
                if(bcrypt.compareSync(req.body.current_password, result[0].	admin_password)){
				var admin_password = bcrypt.hashSync(req.body.new_password, 10);
                var query = "UPDATE `admin` SET `admin_password` = '"+admin_password+"' WHERE `admin`.`admin_id` = "+req.body.admin_id;
				configure.comman_sql_query(query,function(err,rows){
					if(err) {
						res.send({ "status":201, "err":err, "message":"Something went wrong, try again." });
					} else{
						
						res.send({ "status":200, "data":rows, "message":"Password updated Successfully" });
					}
				});
				  
                } else{
					res.send({ "status":201, "data":result, "message":"Invalid old Password" });
                }
            } else{
                res.send({ "status":201, "data":result, "message":"Something went wrong, try again." });
            }
        }
    });
	
});

router.post('/get_all_adminprofile_list',function(req,res,next){
	
	var sqlquery = "select * from admin WHERE admin_id = "+req.body.admin_id;
	
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Fatched Successfully" });
        }
    });
});

router.post('/insert_profile',function(req,res,next){
	var sqlquery = "";
	if(req.body.admin_id== 0){
		sqlquery = "INSERT INTO `admin` (`full_name`, `admin_email`, `contact`) VALUES ('"+req.body.full_name+"', '"+req.body.admin_email+"', '"+req.body.contact+"')";
	}else{
		sqlquery = "update admin set full_name = '"+req.body.full_name+"', admin_email = '"+req.body.admin_email+"', contact = '"+req.body.contact+"' , admin_img = '"+req.body.admin_img+"'  where admin_id= "+req.body.admin_id;
	}
	 
    configure.comman_sql_query(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "err":err, "message":"Something went wrong" });
        } else{
            res.send({ "status":200, "data":rows, "message":"Successfully submitted" });
        }
    });
});


module.exports=router;