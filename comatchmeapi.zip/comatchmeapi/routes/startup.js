var express = require('express');
var router = express.Router();
var Startup=require('../models/startup');

router.post('/createstartup',function(req,res,next){
    var sqlquery = 
    "INSERT INTO `post_startup` (`user_id`,`trying_solve`, `elevator_pitch`, `cofounder_startup`, `doing_startup`, `startup_title`, `short_description`, `startup_phase`, `created_date`, `created_time`) VALUES ('"+ req.body.data.user_id+"','"+ req.body.data.trying_solve+"', '"+req.body.data.elevator_pitch+"', '"+req.body.data.ideal_co_founder+"','"+req.body.data.doing_startup+"','"+req.body.data.title_startup+"','"+req.body.data.description_startup+"','"+req.body.data.phaseSelected+"', CURRENT_TIMESTAMP, CURRENT_TIME)";
	console.log(sqlquery);
	Startup.createStartup(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Startup Creation Failed" });
        } else{
            res.send({ "status":200, "message":"Startup Created Successfully" });
        }
    });  
});

router.post('/getstartups',function(req,res,next){
	console.log(req.body.user_id);
    var sqlquery ="select * from post_startup where user_id = '"+ req.body.user_id+"'";
	Startup.createStartup(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Startup Creation Failed" });
        } else{
            res.send({ "status":200, "startups": rows});
        }
    });  
});
router.post('/getallstartups',function(req,res,next){
	
    var sqlquery ="SELECT post_startup.*, user_registration.first_name, user_registration.email_id FROM post_startup INNER JOIN user_registration ON user_registration.user_id=post_startup.user_id where post_startup.user_id != '"+ req.body.user_id+"' ORDER BY `post_startup`.`startup_id` ASC";
    
	Startup.createStartup(sqlquery,function(err,rows){
        if(err) {
            res.send({ "status":201, "message":"Startup Creation Failed" });
        } else{
            res.send({ "status":200, "startups": rows});
        }
    });  
});


module.exports=router;