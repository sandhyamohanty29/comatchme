var express = require('express');
var router = express.Router();
var Category=require('../models/category');

router.get('/',function(req,res,next){

    Category.getCategory(function(err,rows){
        if(err){
            res.json(err);
        }
        else{
            rows.map(function(data,index){
                Category.getSubcategory(data.menu_category_id,function(err,sub){
                    rows[index]['menu_subcategory']=sub ;
                    if(rows.length == index+1){
                        res.send({ "status":200, "list":rows });
                    }
                })
            })
        }
    });       
});

router.get('/getSubcategoryProduct/:menu_subcategory_id?',function(req,res,next){
    Category.getSubCategoryProduct(req.params.menu_subcategory_id,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else{
            res.json(rows)
        }
    });       
});
router.get('/getSubProduct/:product_category_id?',function(req,res,next){
    Category.getSubProductList(req.params.product_category_id,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else{
            res.json(rows)
        }
    });       
});

module.exports=router;